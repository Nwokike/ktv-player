from channels.base import ChannelData

group_name = "VOD Italy"
country_code = ""

channels = [
    ChannelData(
        name="Sportitalia LIVE24",
        url="https://di-g7ij0rwh.vo.lswcdn.net/sportitalia/silive24.smil/playlist.m3u8",
        logo="https://i.imgur.com/hu56Ya5.png",
        group="VOD Italy",
        country_code="",
        epg_id="Sportitalia24.it"
    ),
    ChannelData(
        name="Sport2U",
        url="https://stream9.xdevel.com/video0s976916-1685/stream/playlist_dvr.m3u8",
        logo="https://i.imgur.com/WW0lNk1.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Grande Fratello Vip Regia 1 Ⓢ Ⓖ",
        url="https://live3.msf.cdn.mediaset.net/content/dash_d0_clr_vos/live/channel(b7",
        logo="https://i.imgur.com/PBTdU4G.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Grande Fratello Vip Regia 2 Ⓢ Ⓖ",
        url="https://live3.msf.cdn.mediaset.net/content/dash_d0_clr_vos/live/channel(b8",
        logo="https://i.imgur.com/FKfwbHD.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Grande Fratello Vip Regia un'ora fa Ⓢ Ⓖ",
        url="https://live3.msf.cdn.mediaset.net/content/dash_d0_clr_vos/live/channel(b9",
        logo="https://i.imgur.com/fFZeBnc.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Stories – Rakuten TV",
        url="https://rakuten-spotlight-6-eu.rakuten.wurl.tv/playlist.m3u8",
        logo="https://i.imgur.com/tMcUvjI.jpg",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Classico – Rakuten TV",
        url="https://rakuten-classico-1-eu.rakuten.wurl.tv/playlist.m3u8",
        logo="https://i.imgur.com/ytN6jfl.jpeg",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Thriller – Rakuten TV",
        url="https://rakuten-thriller-6-eu.rakuten.wurl.tv/playlist.m3u8",
        logo="https://i.imgur.com/jJTnBNk.jpeg",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Commedia – Rakuten TV",
        url="https://rakuten-comedymovies-6-eu.rakuten.wurl.tv/playlist.m3u8",
        logo="https://i.imgur.com/EKKXdIU.jpg",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Documentari – Rakuten TV",
        url="https://rakuten-documentaries-6-eu.rakuten.wurl.tv/playlist.m3u8",
        logo="https://i.imgur.com/rAHBiO8.jpg",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Family – Rakuten TV",
        url="https://rakuten-family-6-eu.rakuten.wurl.tv/playlist.m3u8",
        logo="https://i.imgur.com/BCC123A.jpg",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Romance – Rakuten TV",
        url="https://rakuten-romance-6-eu.rakuten.wurl.tv/playlist.m3u8",
        logo="https://i.imgur.com/TiXrzJZ.jpeg",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Film Top – Rakuten TV",
        url="https://rakuten-topfree-6-eu.rakuten.wurl.tv/playlist.m3u8",
        logo="https://i.imgur.com/OfD9hM9.jpeg",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Drammatico – Rakuten TV",
        url="https://rakuten-tvshows-6-eu.rakuten.wurl.tv/playlist.m3u8",
        logo="https://i.imgur.com/Nx3JzZK.jpg",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Film d'azione – Rakuten TV",
        url="https://rakuten-actionmovies-6-eu.rakuten.wurl.tv/playlist.m3u8",
        logo="https://i.imgur.com/KDmDQM6.jpg",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Euronews in diretta",
        url="https://rakuten-euronews-3-it.samsung.wurl.com/manifest/playlist.m3u8",
        logo="https://i.imgur.com/DUUxsO7.jpeg",
        group="VOD Italy",
        country_code="",
        epg_id="EuronewsItalian.fr"
    ),
    ChannelData(
        name="FailArmy",
        url="https://failarmy-international-it.samsung.wurl.tv/playlist.m3u8",
        logo="https://i.imgur.com/WupT16d.jpg",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="The Pet Collective",
        url="https://the-pet-collective-international-it.samsung.wurl.tv/playlist.m3u8",
        logo="https://i.imgur.com/daTU44g.jpeg",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Canale Europa",
        url="https://canaleeuropa-canaleeuropa-1-it.samsung.wurl.tv/playlist.m3u8",
        logo="https://i.imgur.com/Zw2ZIfz.jpg",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="People Are Awesome",
        url="https://jukin-peopleareawesome-2-it.samsung.wurl.tv/playlist.m3u8",
        logo="https://i.imgur.com/xwz9zKk.jpeg",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Yamato Animation",
        url="https://yamatovideo-yamatoanimation-1-it.samsung.wurl.tv/playlist.m3u8",
        logo="https://i.imgur.com/rOl7HfS.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="BBC Doctor Who",
        url="https://bbceu-doctorwho-1-it.samsung.wurl.tv/playlist.m3u8",
        logo="https://i.imgur.com/J2B9FjO.jpg",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="BBC Drama",
        url="https://bbceu-bbcdrama-2-it.samsung.wurl.tv/playlist.m3u8",
        logo="https://i.imgur.com/hY1M4hL.jpg",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Televisa Telenovelas",
        url="https://televisa-televisa-1-it.samsung.wurl.tv/playlist.m3u8",
        logo="https://i.imgur.com/GaJIRN3.jpg",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Humanity Documentari",
        url="https://cdn-ue1-prod.tsv2.amagi.tv/linear/amg00712-alchimie-humanitydocit-samsungit/playlist.m3u8",
        logo="https://i.imgur.com/4gwdyar.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="The Boat Show",
        url="https://d46c0ebf9ef94053848fdd7b1f2f6b90.mediatailor.eu-central-1.amazonaws.com/v1/master/81bfcafb76f9c947b24574657a9ce7fe14ad75c0/live-prod/4bdea6cd-80c1-11eb-908d-533d39655269/0/master.m3u8",
        logo="https://i.imgur.com/cPTLian.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Fashion TV",
        url="https://fashiontv-fashiontv-3-it.samsung.wurl.com/manifest/playlist.m3u8",
        logo="https://i.imgur.com/KT3zgc1.png",
        group="VOD Italy",
        country_code="",
        epg_id="FashionTVEurope.fr"
    ),
    ChannelData(
        name="Motor1TV",
        url="https://motorsportnetwork-motor1tv-1-it.samsung.wurl.tv/playlist.m3u8",
        logo="https://i.imgur.com/UERYhO1.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="SportOutdoor.tv",
        url="https://gto2000-sportoutdoortv-1-it.samsung.wurl.tv/playlist.m3u8",
        logo="https://i.imgur.com/fwOuEBl.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Italian Fishing TV",
        url="https://itftv-italianfishingtv-1-it.samsung.wurl.tv/playlist.m3u8",
        logo="https://i.imgur.com/Q0jHCdC.png",
        group="VOD Italy",
        country_code="",
        epg_id="ItalianFishingTV.it"
    ),
    ChannelData(
        name="FUEL TV",
        url="https://fueltv-fueltv-6-it.samsung.wurl.com/manifest/playlist.m3u8",
        logo="https://i.imgur.com/4Lzo6M4.png",
        group="VOD Italy",
        country_code="",
        epg_id="FuelTV.us"
    ),
    ChannelData(
        name="Teletubbies",
        url="https://dhx-teletubbies-2-it.samsung.wurl.tv/playlist.m3u8",
        logo="https://i.imgur.com/tSw1oON.jpeg",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="duckTV",
        url="https://mmm-ducktv-2-it.samsung.wurl.com/manifest/playlist.m3u8",
        logo="https://i.imgur.com/BKoAJZV.jpeg",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="SuperToons TV",
        url="https://kedoo-supertoonstv-4-it.samsung.wurl.tv/playlist.m3u8",
        logo="https://i.imgur.com/A6vCYsC.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Planeta Junior",
        url="https://deaplaneta-planetakidz-2-it.samsung.wurl.tv/playlist.m3u8",
        logo="https://i.imgur.com/F71WMja.jpg",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="MONDO TV KIDS",
        url="https://mondotv-mondotvkids-1-it.samsung.wurl.tv/playlist.m3u8",
        logo="https://i.imgur.com/DMqKFIM.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Vevo Pop",
        url="https://601820eb2b971a000104f40a-samsung.eu.ssai.zype.com/601820eb2b971a000104f40a_samsung_eu/manifest.m3u8",
        logo="https://i.imgur.com/DPqMpQC.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Radio Italia Trend",
        url="https://radioitalia-samsungitaly.amagi.tv/playlist.m3u8",
        logo="https://i.imgur.com/ecpfn3e.png",
        group="VOD Italy",
        country_code="",
        epg_id="RadioItaliaTrendTV.it"
    ),
    ChannelData(
        name="Clubbing TV",
        url="https://clubbingtv-samsunguk.amagi.tv/playlist.m3u8",
        logo="https://i.imgur.com/D1IuAqu.jpg",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Deluxe Lounge HD",
        url="https://d46c0ebf9ef94053848fdd7b1f2f6b90.mediatailor.eu-central-1.amazonaws.com/v1/master/81bfcafb76f9c947b24574657a9ce7fe14ad75c0/live-prod/9f58b8c3-80c1-11eb-908d-533d39655269/0/master.m3u8",
        logo="https://i.imgur.com/LzIsXym.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Trace Latina Ⓖ",
        url="https://cdn-ue1-prod.tsv2.amagi.tv/linear/amg01131-tracetv-tracelatinait-samsungit/playlist.m3u8",
        logo="https://i.imgur.com/GHbz8wd.png",
        group="VOD Italy",
        country_code="",
        epg_id="TraceLatina.fr"
    ),
    ChannelData(
        name="Trace Urban Ⓖ",
        url="https://cdn-ue1-prod.tsv2.amagi.tv/linear/amg01131-tracetv-traceurbanit-samsungit/playlist.m3u8",
        logo="https://i.imgur.com/PAx9qj8.png",
        group="VOD Italy",
        country_code="",
        epg_id="TraceUrban.fr"
    ),
    ChannelData(
        name="Full Moon",
        url="https://minerva-fullmoon-1-it.samsung.wurl.tv/playlist.m3u8",
        logo="https://i.imgur.com/0xT7bZP.jpg",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Cinema Segreto",
        url="https://minerva-cinemasegreto-1-it.samsung.wurl.tv/playlist.m3u8",
        logo="https://i.imgur.com/pID3ZGx.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Bizzarro Movies",
        url="https://minerva-bizzarromovies-1-it.samsung.wurl.tv/playlist.m3u8",
        logo="https://i.imgur.com/EbDLnZB.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="CGtv",
        url="https://cgentertainment-cgtv-1-it.samsung.wurl.tv/playlist.m3u8",
        logo="https://i.imgur.com/6rsLtY7.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="WP",
        url="https://minerva-wp-1-it.samsung.wurl.tv/playlist.m3u8",
        logo="https://i.imgur.com/W5I5yY0.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Risate all'italiana",
        url="https://minerva-risateallitaliana-1-it.samsung.wurl.tv/playlist.m3u8",
        logo="https://i.imgur.com/LCN66Z1.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Shorts Ⓖ",
        url="https://cdn-ue1-prod.tsv2.amagi.tv/linear/amg00784-shortsinternati-shortstv-fast-italy-samsungit/playlist.m3u8",
        logo="https://i.imgur.com/GwM7RHV.jpg",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Sofy.tv",
        url="https://sofytv-samsungit.amagi.tv/playlist.m3u8",
        logo="https://i.imgur.com/fsJFJeZ.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="VH1+ Girl Power! – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/655208ff53fc9700084a834e/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/Z4t6fdU.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Car Chase – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/65a939fad77d450008863835/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/F1jXkhK.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Monster Jam – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/65bce7f1d77d450008b3a430/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/jxGhINd.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="MacGyver – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/6245d4511358320007029cdf/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/bz9IwWU.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Settimo Cielo – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/6245d3792792150007e20634/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/TC5lo6r.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="BBC Drama – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/62e7fa5ab5062e0007dcf97d/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/CrAqXHJ.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Le sorelle mcleod – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/60a2837f8154ab0007c4dcdf/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/P310ryf.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Autostop per il cielo – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/638f286445264d00084ec6dc/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/rpC1qk7.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Renegade – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/634926e4b51d2d00077819a2/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/Qsd9wuS.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Serie – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/60b9ff2722bfa400072676ef/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/CHBhRZr.png",
        group="VOD Italy",
        country_code="",
        epg_id="PlutoTVSerieItaly.it"
    ),
    ChannelData(
        name="Film – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/608aa17fb9f4490007e6419a/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/QeFc7F3.png",
        group="VOD Italy",
        country_code="",
        epg_id="PlutoTVFilmItaly.it"
    ),
    ChannelData(
        name="Film Azione – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/608aa20a2e7f270007c4878d/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/ZmAuf3H.png",
        group="VOD Italy",
        country_code="",
        epg_id="PlutoTVFilmAzioneItaly.it"
    ),
    ChannelData(
        name="Film Thriller – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/608aa5e995132a00075f7005/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/hIWMGRW.png",
        group="VOD Italy",
        country_code="",
        epg_id="PlutoTVFilmThrillerItaly.it"
    ),
    ChannelData(
        name="Horror – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/61c09e3ac210ed0007606620/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/zhoHRSE.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Western – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/62e7fb67478a5b0007e6c50c/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/6vmgQBl.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Film Classici – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/608aa3c446d73500075f0e24/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/jNyZPLV.png",
        group="VOD Italy",
        country_code="",
        epg_id="PlutoTVFilmClassiciItaly.it"
    ),
    ChannelData(
        name="Cinema Italiano – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/608aa7d8359b270007861489/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/drDX5DC.png",
        group="VOD Italy",
        country_code="",
        epg_id="PlutoTVCinemaItalianoItaly.it"
    ),
    ChannelData(
        name="Totò – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/65253f9881f942000833ccd5/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/wLDteJZ.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Film Romantici – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/608aa4a4cc92820007b663af/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/KxPsLG3.png",
        group="VOD Italy",
        country_code="",
        epg_id="PlutoTVFilmRomanticiItaly.it"
    ),
    ChannelData(
        name="Christmas – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/612e05b885183d0007958101/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/tQ8lN30.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Film Drama – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/608aa42b5c2b8f0007197529/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/X8jimKP.png",
        group="VOD Italy",
        country_code="",
        epg_id="PlutoTVFilmDramaItaly.it"
    ),
    ChannelData(
        name="Film Commedia – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/608aa512d67fd900072323db/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/cSKaVHW.png",
        group="VOD Italy",
        country_code="",
        epg_id="PlutoTVFilmCommediaItaly.it"
    ),
    ChannelData(
        name="East is East – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/654c955683595c00081d9d87/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/iPGv82f.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="The Asylum – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/62e8d5369e48940007fc1dc1/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/S2jlaiJ.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Star Trek: The Original Series – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/6581a09edfed030008e12b39/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/VnUrFqB.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Doctor Who – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/62e7f8db27ce19000732d1aa/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/oewPc3b.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Sci-Fi – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/61728bb9ee3773000840c1fa/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/5B94N8g.png",
        group="VOD Italy",
        country_code="",
        epg_id="PlutoTVSciFiItaly.it"
    ),
    ChannelData(
        name="Mutant X – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/60802c209a26320007c92ad5/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/SptYKFI.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Andromeda – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/60802d37ee238e0007c94e64/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/2HFhwX9.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Sanctuary – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/63eb57d6c111bc0008fe2658/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/iYyijeJ.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Forensic Files – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/64ec5cf50f73a800081310a5/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/hF5maH7.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Squadra Speciale Cobra 11 – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/625e6cc905e09f00073addee/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/HtDoAF2.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Crime – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/608aa777b907770007e5d05d/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/WRMGIdb.png",
        group="VOD Italy",
        country_code="",
        epg_id="PlutoTVCrimeItaly.it"
    ),
    ChannelData(
        name="Mai dire sì – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/6349279ed5023700078f2bc2/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/yIMyhSN.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Consulenze illegali – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/60b9dc99521a1400079bdfba/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/AoOiYJX.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Il banco dei pugni – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/60e4507a06171800072339a3/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/2Lj1sdf.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Affare Fatto – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/64ec5c6644fe100009d114ae/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/BuGkGsL.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Catfish – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/6093f9ed2c75660007322bb7/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/KajHKoP.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Il Testimone – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/61fbd3f0733df400076c9a2d/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/9NXL9kY.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Case Pazzesche – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/626bb07a58b8dd0007e9f36e/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/v8IDWwX.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Geordie Shore – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/619263ee9541940007d20d60/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/y0fkHVi.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Ex on the beach – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/60940ebad67fd900072382db/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/IONkdyk.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="#Riccanza – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/626baa721c279b00072cbedd/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/oBpcWEm.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="The Hills – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/6466007181844c000967f80a/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/9SRojGx.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Reality – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/61925f874b1ec000075e700a/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/tPEOeTk.png",
        group="VOD Italy",
        country_code="",
        epg_id="PlutoTVRealityItaly.it"
    ),
    ChannelData(
        name="Made – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/6304ee20112ca70007d8accc/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/dguQsJ7.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="16 anni e incinta – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/60940a07d88ba90007b9cb71/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/4BHrbP7.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Teen Mom – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/62e7fc8c0d061100083946a9/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/LdiTgeW.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Jersey Shore – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/63eb5767da71180008ace8fc/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/HIlmQEy.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Top Gear – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/64c109a4798def0008a6e03e/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/ZZo7DXQ.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Pimp My Ride – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/636a4eaf77279a0007f14861/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/GC2wj2K.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="World poker tour – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/608016e446d73500075ea7e0/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/AF1ON8u.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="PFL MMA – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/654a299cab05240008a12639/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/zScgLTv.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Robot Wars by MECH+ – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/651581ba6a84140008593586/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/vGqha3k.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Ultimate Classic Wrestling – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/652516fb7971630008a58e74/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/QVN5qv3.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="The Boat Show – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/63eb58aa60bc8f0008caa8f8/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/aDcwRvj.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Unbeaten Sports – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/64c3b106dac71b00080a26d2/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/UAiv612.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Sport – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/608030eff4b6f70007e1684c/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/o2psAYW.png",
        group="VOD Italy",
        country_code="",
        epg_id="PlutoTVSportItaly.it"
    ),
    ChannelData(
        name="Ridiculousness – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/61fbd721e5b49e00079bfedc/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/Yyj3Dm6.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Scherzi e risate – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/609404b0a8ec810007d8de9d/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/kPxGzPI.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Fail army – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/608014d19a26320007c92ab6/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/SqRDd2U.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="People are awesome – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/608017cbe375e400070cc981/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/jn0OeWv.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="The pet collective – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/60801317a0ccef00072aaf75/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/034PrSz.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Just for laughs – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/6093f48c95132a00075fd859/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/VvEz0XX.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="South Park – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/62bc1f502b70e3000706298e/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/06wIdRV.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Super! Spongebob – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/6093f9281db477000759fce0/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/vFiwODM.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Due Fantagenitori – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/62b57a6752a0060008bc65cd/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/HOvLgGK.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Yu-Gi-Oh! – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/63eb82e24e83e70008ab735f/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/rmzSC1C.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Anime – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/65b90daed77d450008a43345/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/rhVF0eC.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Avatar – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/624da1cd2af90c0007c13205/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/KDSStnJ.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Inazuma Eleven – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/612375086abc84000738fc03/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/2u1ic6X.png",
        group="VOD Italy",
        country_code="",
        epg_id="PlutoTVAnimeItaly.it"
    ),
    ChannelData(
        name="Super! Rugrats – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/62e8ddbbaed0390007b258a6/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/QqMQZte.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Teenage Mutant Ninja Turtles – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/62619405c733e8000732d1fe/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/bAnyjH7.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Super! Icarly – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/609401db8cf51c00084b592e/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/Mhl252U.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Super! Victorious – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/63c012504faf1c0007abfa93/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/ArXLm5R.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Super! Zoey 101 – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/6304ed62410a4c00083c0291/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/7FCQb1G.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Super! POP – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/6093f7b5bb49b90007cecaad/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/jlz31HP.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Super! Gaming – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/626192c51c279b00072c4553/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/UB7xHRQ.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Super! Girl Power – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/636a4ce50728d200072eebe7/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/lzgp9GM.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Super! Intervallo – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/62619544b1bf740007b4154b/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/jl7ZvE5.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Super! Spyders – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/655207f8b9c8a700082c7951/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/n89yuZh.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Kids – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/62444e195d2ab7000861694b/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/ybd7A0r.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Kids Ukraine – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/622a2d8da9d8210007d918c2/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/MrIlypV.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Super! Star – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/6093f6f8351eb0000754afb8/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/YLtqPkF.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Super! Risate – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/63eb573ba99571000897135b/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/ALCbqZt.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Super! Brothers and Sisters – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/61925ea79541940007d20881/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/KSQvVye.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="VH1+ Music Legends – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/62e8cc10ca869f00078efca8/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/kJ1MDVi.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="VH1+ Back to 90's – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/6552085aab05240008b05f6c/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/vGgh3cs.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="VH1+ Rock! – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/636a4173e34fd50007534542/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/P1OCuFl.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="VH1+ Canzoni Italiane – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/63724270c7c2360007b170e8/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/fpQBKP2.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="VH1+ Hip Hop & Rap – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/6465fef47cb4b100086ee7bd/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/k1zQpiO.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Deluxe Lounge HD – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/6278ec6c33d85a00077ad814/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/mTXgaKl.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="K-Pop – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/60c8b75fb0a68400074b86fc/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/9Vp4rx2.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Fireplace – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/612ce23f51cce000078eeed5/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/csk1e76.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Euronews – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/61b86ea479a4390007c6d5fc/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/Zpf2ykM.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="CBS News – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/6231ec4b62cd1f0007093c7b/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/ApsK6Eq.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Cucina – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/608aa718a8ec810007d87fee/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/KsOhaOn.png",
        group="VOD Italy",
        country_code="",
        epg_id="PlutoTVCucinaItaly.it"
    ),
    ChannelData(
        name="Real life – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/60801976f92a750007a0699c/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/FpwqJYw.png",
        group="VOD Italy",
        country_code="",
        epg_id="PlutoTVRealLifeItaly.it"
    ),
    ChannelData(
        name="Naturescape – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/610a9ebe8c2ac2000734776e/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/CGB6qiV.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Natura – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/60802b37709d6b0007b0c549/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/Pc4gx12.png",
        group="VOD Italy",
        country_code="",
        epg_id="PlutoTVNaturaItaly.it"
    ),
    ChannelData(
        name="Storia – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/65253fdf3fd33c00080214a3/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/w5BYvsz.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Documentari – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/608aa8a5709d6b0007b132fe/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/0jYrODf.png",
        group="VOD Italy",
        country_code="",
        epg_id="PlutoTVDocumentariItaly.it"
    ),
    ChannelData(
        name="Viaggi – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/63c923944207be0007fd0887/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/3GJg0uy.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="House of Docs – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/6536608b4f123d000876b78b/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/pFLQ18m.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
    ChannelData(
        name="Le vite degli altri – Pluto TV",
        url="https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/653660b4295b840008a70ba3/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel",
        logo="https://i.imgur.com/nngMFi5.png",
        group="VOD Italy",
        country_code="",
        epg_id=""
    ),
]
