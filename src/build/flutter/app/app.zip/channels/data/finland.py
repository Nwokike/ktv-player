from channels.base import ChannelData

group_name = "Finland"
country_code = "FI"

channels = [
    ChannelData(
        name="Yle TV1 Ⓖ",
        url="https://yletv.akamaized.net/hls/live/622365/yletv1fin/index.m3u8",
        logo="https://i.imgur.com/6yXZwUL.png",
        group="Finland",
        country_code="FI",
        epg_id="YleTV1.fi"
    ),
    ChannelData(
        name="Yle TV2 Ⓖ",
        url="https://yletv.akamaized.net/hls/live/622366/yletv2fin/index.m3u8",
        logo="https://i.imgur.com/4xkc6PL.png",
        group="Finland",
        country_code="FI",
        epg_id="YleTV2.fi"
    ),
    ChannelData(
        name="MTV3",
        url="https://live-fi.tvkaista.net/mtv3/live.m3u8?src=freetv",
        logo="https://i.imgur.com/kNbmc8n.png",
        group="Finland",
        country_code="FI",
        epg_id="MTV3.fi"
    ),
    ChannelData(
        name="Nelonen",
        url="https://live-fi.tvkaista.net/nelonen/live.m3u8?src=freetv",
        logo="https://i.imgur.com/BFbCyfY.png",
        group="Finland",
        country_code="FI",
        epg_id="Nelonen.fi"
    ),
    ChannelData(
        name="Yle Teema Fem Ⓖ",
        url="https://yletv.akamaized.net/hls/live/622367/yletvteemafemfin/index.m3u8",
        logo="https://i.imgur.com/iDljufz.png",
        group="Finland",
        country_code="FI",
        epg_id="YleTeemaFem.fi"
    ),
    ChannelData(
        name="MTV Sub",
        url="https://live-fi.tvkaista.net/sub/live.m3u8?src=freetv",
        logo="https://i.imgur.com/VRCuxQt.png",
        group="Finland",
        country_code="FI",
        epg_id="Sub.fi"
    ),
    ChannelData(
        name="TV5 Finland",
        url="https://live-fi.tvkaista.net/tv5/live.m3u8?src=freetv",
        logo="https://i.imgur.com/MoukyGs.png",
        group="Finland",
        country_code="FI",
        epg_id="TV5.fi"
    ),
    ChannelData(
        name="Liv",
        url="https://live-fi.tvkaista.net/liv/live.m3u8?src=freetv",
        logo="https://upload.wikimedia.org/wikipedia/commons/0/06/Liv_color_RGB.png",
        group="Finland",
        country_code="FI",
        epg_id="Liv.fi"
    ),
    ChannelData(
        name="Jim",
        url="https://live-fi.tvkaista.net/jim/live.m3u8?src=freetv",
        logo="https://upload.wikimedia.org/wikipedia/commons/9/92/Jim_color_RGB.png",
        group="Finland",
        country_code="FI",
        epg_id="Jim.fi"
    ),
    ChannelData(
        name="Kutonen",
        url="https://live-fi.tvkaista.net/kutonen/live.m3u8?src=freetv",
        logo="https://i.imgur.com/4giVyxb.png",
        group="Finland",
        country_code="FI",
        epg_id="Kutonen.fi"
    ),
    ChannelData(
        name="TLC Finland",
        url="https://live-fi.tvkaista.net/tlc/live.m3u8?src=freetv",
        logo="https://i.imgur.com/0d5hP3A.png",
        group="Finland",
        country_code="FI",
        epg_id="TLCFinland.fi"
    ),
    ChannelData(
        name="Star Channel Finland",
        url="https://live-fi.tvkaista.net/star-channel/live.m3u8?src=freetv",
        logo="https://upload.wikimedia.org/wikipedia/commons/thumb/8/89/Star_Channel_2020.svg/640px-Star_Channel_2020.svg.png",
        group="Finland",
        country_code="FI",
        epg_id="StarChannel.fi"
    ),
    ChannelData(
        name="MTV Ava",
        url="https://live-fi.tvkaista.net/ava/live.m3u8?src=freetv",
        logo="https://i.imgur.com/rtyJVgB.png",
        group="Finland",
        country_code="FI",
        epg_id="AVA.fi"
    ),
    ChannelData(
        name="Hero",
        url="https://live-fi.tvkaista.net/hero/live.m3u8?src=freetv",
        logo="https://upload.wikimedia.org/wikipedia/commons/b/bd/Hero_color_RGB.png",
        group="Finland",
        country_code="FI",
        epg_id="Hero.fi"
    ),
    ChannelData(
        name="Frii",
        url="https://live-fi.tvkaista.net/frii/live.m3u8?src=freetv",
        logo="https://i.imgur.com/ljKoG9I.png",
        group="Finland",
        country_code="FI",
        epg_id="Frii.fi"
    ),
    ChannelData(
        name="Alfa Ⓢ",
        url="https://irrtv2.digitacdn.net/live/ott/irrtv/playlist.m3u8?organizationId=229401409&suiteItemId=230439940",
        logo="https://upload.wikimedia.org/wikipedia/fi/9/93/IRR-TV-1.png",
        group="Finland",
        country_code="FI",
        epg_id="IRRTV.fi"
    ),
    ChannelData(
        name="TapahtumaTV Eveo",
        url="https://live-fi.tvkaista.net/tapahtumatv-eveo/live.m3u8?src=freetv",
        logo="https://i.imgur.com/sR8nA8w.png",
        group="Finland",
        country_code="FI",
        epg_id="Eveo.fi"
    ),
    ChannelData(
        name="National Geographic Finland Ⓖ",
        url="https://live-fi.tvkaista.net/national-geographic/live.m3u8?src=freetv",
        logo="https://upload.wikimedia.org/wikipedia/commons/thumb/f/fc/Natgeologo.svg/512px-Natgeologo.svg.png",
        group="Finland",
        country_code="FI",
        epg_id="NationalGeographicFinland.fi"
    ),
    ChannelData(
        name="Viaplay TV",
        url="https://live-fi.tvkaista.net/viaplay-tv/live.m3u8?src=freetv",
        logo="https://upload.wikimedia.org/wikipedia/commons/thumb/9/94/Viaplay_TV_logo.svg/640px-Viaplay_TV_logo.svg.png",
        group="Finland",
        country_code="FI",
        epg_id="ViaplayTV.fi"
    ),
    ChannelData(
        name="OnniTV",
        url="https://onnitv.digitacdn.net/live/ott/onnitv/playlist.m3u8?organizationId=83459409&suiteItemId=83459780",
        logo="https://i.imgur.com/HzILf2H.png",
        group="Finland",
        country_code="FI",
        epg_id="KotiTV.fi"
    ),
    ChannelData(
        name="Taivas TV7",
        url="https://vod.tv7.fi/tv7-fi/_definst_/smil:tv7-fi.smil/playlist.m3u8",
        logo="https://i.imgur.com/a4iNVXA.png",
        group="Finland",
        country_code="FI",
        epg_id="TaivasTV7.fi"
    ),
    ChannelData(
        name="Himlen TV7",
        url="https://vod.tv7.fi/tv7-se/_definst_/smil:tv7-se.smil/playlist.m3u8",
        logo="https://i.imgur.com/a4iNVXA.png",
        group="Finland",
        country_code="FI",
        epg_id="HimlenTV7.fi"
    ),
    ChannelData(
        name="MTV Uutiset Live",
        url="https://live.streaming.a2d.tv/asset/20025962.isml/.m3u8",
        logo="https://i.imgur.com/IyB6mIb.png",
        group="Finland",
        country_code="FI",
        epg_id="MTVUutiset.fi"
    ),
    ChannelData(
        name="Nopola News",
        url="https://virta2.nopolanews.fi:8443/live/smil:Stream1.smil/playlist.m3u8",
        logo="https://i.imgur.com/gOj8J6O.png",
        group="Finland",
        country_code="FI",
        epg_id="NopolaNews.fi"
    ),
    ChannelData(
        name="När-TV Ⓢ",
        url="https://streaming.nartv.fi/live/ngrp:NAR_TV.stream_all/playlist.m3u8",
        logo="https://i.imgur.com/Ht5yePq.png",
        group="Finland",
        country_code="FI",
        epg_id="NarTV.fi"
    ),
    ChannelData(
        name="Sundom TV Ⓨ",
        url="https://www.youtube.com/@SundomTV/live",
        logo="https://i.imgur.com/WgwR7nJ.png",
        group="Finland",
        country_code="FI",
        epg_id="SundomTV.fi"
    ),
    ChannelData(
        name="Wör TV Ⓨ",
        url="https://www.youtube.com/@wor-tvr.f.4461/live",
        logo="https://i.imgur.com/P9O1jo0.png",
        group="Finland",
        country_code="FI",
        epg_id="WorTV.fi"
    ),
    ChannelData(
        name="YleX Studio Live",
        url="https://ylestudiolive.akamaized.net/hls/live/2007826/ylestudiolive-YleX/master.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/YleX.svg/450px-YleX.svg.png",
        group="Finland",
        country_code="FI",
        epg_id="YleX.fi"
    ),
    ChannelData(
        name="Järviradio TV",
        url="https://streamer.radiotaajuus.fi/memfs/47f113bf-04ea-493b-a9d4-52945fd9db31.m3u8",
        logo="https://jarviradio.fi/jrtv2/wp-content/uploads/2022/01/jrtv1.jpg",
        group="Finland",
        country_code="FI",
        epg_id="JRTVJarviradio.fi"
    ),
]
