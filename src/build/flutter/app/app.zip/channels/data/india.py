from channels.base import ChannelData

group_name = "India"
country_code = "IN"

channels = [
    ChannelData(
        name="NDTV India",
        url="https://ndtvindiaelemarchana.akamaized.net/hls/live/2003679/ndtvindia/master.m3u8",
        logo="https://i.imgur.com/QjJYohG.png",
        group="India",
        country_code="IN",
        epg_id="NDTVIndia.in"
    ),
    ChannelData(
        name="ABP News",
        url="https://abplivetv.pc.cdn.bitgravity.com/httppush/abp_livetv/abp_abpnews/master.m3u8",
        logo="https://i.imgur.com/DKHUFVQ.png",
        group="India",
        country_code="IN",
        epg_id="ABPNews.in"
    ),
    ChannelData(
        name="ABP Ananda",
        url="https://abplivetv.pc.cdn.bitgravity.com/httppush/abp_livetv/abp_ananda/master.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/commons/thumb/c/cd/ABP_Ananda_logo.svg/500px-ABP_Ananda_logo.svg.png",
        group="India",
        country_code="IN",
        epg_id="ABPAnanda.in"
    ),
    ChannelData(
        name="DD National Ⓨ",
        url="https://www.youtube.com/doordarshan/live",
        logo="https://i.imgur.com/MohlE5B.png",
        group="India",
        country_code="IN",
        epg_id="DDNational.in"
    ),
    ChannelData(
        name="DD News Ⓨ",
        url="https://www.youtube.com/c/ddnews/live",
        logo="https://i.imgur.com/znnVCEf.png",
        group="India",
        country_code="IN",
        epg_id="DDNews.in"
    ),
    ChannelData(
        name="DD India Ⓨ",
        url="https://www.youtube.com/DDIndia/live",
        logo="https://i.imgur.com/45uptR8.png",
        group="India",
        country_code="IN",
        epg_id="DDIndia.in"
    ),
    ChannelData(
        name="DD Bharati Ⓨ",
        url="https://www.youtube.com/@ddbharati/live",
        logo="https://i.imgur.com/4tfUIEo.png",
        group="India",
        country_code="IN",
        epg_id="DDBharati.in"
    ),
    ChannelData(
        name="DD Kisan Ⓨ",
        url="https://www.youtube.com/@DDKisan/live",
        logo="https://i.imgur.com/x56WJEa.png",
        group="India",
        country_code="IN",
        epg_id="DDKisan.in"
    ),
    ChannelData(
        name="DD Urdu Ⓨ",
        url="https://www.youtube.com/@DDUrdu/live",
        logo="https://i.imgur.com/OiQPS34.png",
        group="India",
        country_code="IN",
        epg_id="DDUrdu.in"
    ),
    ChannelData(
        name="India Today Ⓨ",
        url="https://www.youtube.com/watch?v=sYZtOFzM78M",
        logo="https://i.imgur.com/C7KK3Fd.png",
        group="India",
        country_code="IN",
        epg_id="IndiaToday.in"
    ),
    ChannelData(
        name="Aaj Tak Ⓨ",
        url="https://www.youtube.com/watch?v=Nq2wYlWFucg",
        logo="https://upload.wikimedia.org/wikipedia/commons/2/28/Aaj_tak_logo.png",
        group="India",
        country_code="IN",
        epg_id="AajTak.in"
    ),
    ChannelData(
        name="India TV Ⓨ",
        url="https://www.youtube.com/watch?v=e1FIApIafWE",
        logo="https://upload.wikimedia.org/wikipedia/en/thumb/6/60/India_tv_logo-en.png/500px-India_tv_logo-en.png",
        group="India",
        country_code="IN",
        epg_id="IndiaTV.in"
    ),
    ChannelData(
        name="TV9 Bharatvarsh Ⓨ",
        url="https://www.youtube.com/watch?v=nSpwwcHVp80",
        logo="https://upload.wikimedia.org/wikipedia/en/thumb/a/a6/TV9_Bharatvarsh.svg/500px-TV9_Bharatvarsh.svg.png",
        group="India",
        country_code="IN",
        epg_id="TV9Bharatvarsh.in"
    ),
    ChannelData(
        name="Republic Bharat Ⓨ",
        url="https://www.youtube.com/watch?v=3DbTO_AMhhc",
        logo="https://upload.wikimedia.org/wikipedia/commons/thumb/8/80/Republic_Bharat_logo.svg/500px-Republic_Bharat_logo.svg.png",
        group="India",
        country_code="IN",
        epg_id="RepublicBharat.in"
    ),
]
