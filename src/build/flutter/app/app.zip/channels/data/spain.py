from channels.base import ChannelData

group_name = "Spain"
country_code = "ES"

channels = [
    ChannelData(
        name="La 1",
        url="https://dh6vo1bovy43s.cloudfront.net/v1/master/3722c60a815c199d9c0ef36c5b73da68a62b09d1/cc-x3gcl32l5ffq2/La_1_ES.m3u8",
        logo="https://i.imgur.com/NbesiPn.png",
        group="Spain",
        country_code="ES",
        epg_id="La1.es"
    ),
    ChannelData(
        name="La 2",
        url="https://di2qeq48iv8ps.cloudfront.net/v1/master/3722c60a815c199d9c0ef36c5b73da68a62b09d1/cc-o8u23e6v7vptv/La_2_ES.m3u8",
        logo="https://i.imgur.com/DmuTwDw.png",
        group="Spain",
        country_code="ES",
        epg_id="La2.es"
    ),
    ChannelData(
        name="Antena 3",
        url="http://185.189.225.150:85/Antena3HD/index.m3u8",
        logo="https://i.imgur.com/j3SP4BS.png",
        group="Spain",
        country_code="ES",
        epg_id="Antena3.es"
    ),
    ChannelData(
        name="Cuatro",
        url="http://185.189.225.150:85/CuatroHD/index.m3u8",
        logo="https://i.imgur.com/zROxNap.png",
        group="Spain",
        country_code="ES",
        epg_id="Cuatro.es"
    ),
    ChannelData(
        name="Telecinco",
        url="http://185.189.225.150:85/TeleCincoHD/index.m3u8",
        logo="https://i.imgur.com/JECsKdk.png",
        group="Spain",
        country_code="ES",
        epg_id="Telecinco.es"
    ),
    ChannelData(
        name="La Sexta",
        url="http://185.189.225.150:85/LaSexta/index.m3u8",
        logo="https://i.imgur.com/b59MxgM.png",
        group="Spain",
        country_code="ES",
        epg_id="LaSexta.es"
    ),
    ChannelData(
        name="24h",
        url="https://d3pfmk89wc0vm9.cloudfront.net/v1/master/3722c60a815c199d9c0ef36c5b73da68a62b09d1/cc-nlow3qkp9tmdm/24H_ES.m3u8",
        logo="https://i.imgur.com/ZKR2jKr.png",
        group="Spain",
        country_code="ES",
        epg_id="24h.es"
    ),
    ChannelData(
        name="tdp",
        url="https://rtvelivestream.akamaized.net/rtvesec/tdp/tdp_main.m3u8",
        logo="https://i.imgur.com/HliegRJ.png",
        group="Spain",
        country_code="ES",
        epg_id="tdp.es"
    ),
    ChannelData(
        name="clan",
        url="https://rtvelivestream.akamaized.net/rtvesec/clan/clan_main_dvr.m3u8",
        logo="https://i.imgur.com/38xIfQ3.png",
        group="Spain",
        country_code="ES",
        epg_id="clan.es"
    ),
    ChannelData(
        name="TVE Internacional Europe-Asia",
        url="https://rtvelivestream.akamaized.net/rtvesec/int/tvei_eu_main_dvr.m3u8",
        logo="https://i.imgur.com/ow1HArj.png",
        group="Spain",
        country_code="ES",
        epg_id="TVEInternacionalEuropeAsia.es"
    ),
    ChannelData(
        name="Neox Ⓢ",
        url="http://185.189.225.150:85/neox/index.m3u8",
        logo="https://raw.githubusercontent.com/tv-logo/tv-logos/refs/heads/main/countries/spain/neox-es.png",
        group="Spain",
        country_code="ES",
        epg_id="Neox.es"
    ),
    ChannelData(
        name="Nova Ⓢ",
        url="http://185.189.225.150:85/nova/index.m3u8",
        logo="https://raw.githubusercontent.com/tv-logo/tv-logos/refs/heads/main/countries/spain/nova-es.png",
        group="Spain",
        country_code="ES",
        epg_id="Nova.es"
    ),
    ChannelData(
        name="Mega Ⓢ",
        url="http://185.189.225.150:85/mega/index.m3u8",
        logo="https://i.imgur.com/Udrt2eK.png",
        group="Spain",
        country_code="ES",
        epg_id="Mega.es"
    ),
    ChannelData(
        name="Atreseries Ⓢ",
        url="http://181.78.109.48:8000/play/a00l/index.m3u8",
        logo="https://raw.githubusercontent.com/tv-logo/tv-logos/refs/heads/main/countries/spain/atreseries-es.png",
        group="Spain",
        country_code="ES",
        epg_id="Atreseries.es"
    ),
    ChannelData(
        name="FDF",
        url="http://185.189.225.150:85/fdf/index.m3u8",
        logo="https://raw.githubusercontent.com/tv-logo/tv-logos/refs/heads/main/countries/spain/fdf-es.png",
        group="Spain",
        country_code="ES",
        epg_id="FactoriadeFiccion.es"
    ),
    ChannelData(
        name="Divinity Ⓖ",
        url="https://directos.divinity.es/orilinear04/live/linear04/main/main.isml/main-audio_spa=128000-video=1500000.m3u8",
        logo="https://i.imgur.com/o7fvEr6.png",
        group="Spain",
        country_code="ES",
        epg_id="Divinity.es"
    ),
    ChannelData(
        name="Energy Ⓖ",
        url="https://directos.energytv.es/orilinear03/live/linear03/main/main.isml/main-audio_spa=128000-video=1500000.m3u8",
        logo="https://raw.githubusercontent.com/tv-logo/tv-logos/refs/heads/main/countries/spain/energy-es.png",
        group="Spain",
        country_code="ES",
        epg_id="Energy.es"
    ),
    ChannelData(
        name="Boing",
        url="http://185.189.225.150:85/boing/index.m3u8",
        logo="https://i.imgur.com/nUYuCAP.png",
        group="Spain",
        country_code="ES",
        epg_id="Boing.es"
    ),
    ChannelData(
        name="Be Mad Ⓖ",
        url="https://directos.bemad.es/orilinear02/live/linear02/main/main.isml/main-audio_spa=128000-video=1500000.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/commons/thumb/7/70/Be_Mad_TV.svg/512px-Be_Mad_TV.svg.png",
        group="Spain",
        country_code="ES",
        epg_id="BeMad.es"
    ),
    ChannelData(
        name="Paramount Network",
        url="http://185.189.225.150:85/Paramount/index.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/commons/thumb/9/9f/Paramount_Network.svg/512px-Paramount_Network.svg.png",
        group="Spain",
        country_code="ES",
        epg_id="ParamountNetwork.es"
    ),
    ChannelData(
        name="RNE para todos",
        url="https://rtvelivestream.akamaized.net/rtvesec/rne/rne_para_todos_main.m3u8",
        logo="https://graph.facebook.com/radionacionalrne/picture?width=200&height=200",
        group="Spain",
        country_code="ES",
        epg_id="RNE.es"
    ),
    ChannelData(
        name="euronews",
        url="https://euronews-live-spa-es.fast.rakuten.tv/v1/master/0547f18649bd788bec7b67b746e47670f558b6b2/production-LiveChannel-6571/bitok/eyJzdGlkIjoiMDA0YjY0NTMtYjY2MC00ZTZkLTlkNzEtMTk3YTM3ZDZhZWIxIiwibWt0IjoiZXMiLCJjaCI6NjU3MSwicHRmIjoxfQ==/26034/euronews-es.m3u8",
        logo="https://raw.githubusercontent.com/tv-logo/tv-logos/refs/heads/main/countries/international/euro-news-int.png",
        group="Spain",
        country_code="ES",
        epg_id="Euronews.es"
    ),
    ChannelData(
        name="El País",
        url="https://d2xqbi89ghm9hh.cloudfront.net/v1/master/3722c60a815c199d9c0ef36c5b73da68a62b09d1/cc-79fx3huimw4xc-ssai-prd/fast-channel-el-pais.m3u8",
        logo="https://graph.facebook.com/elpais/picture?width=200&height=200",
        group="Spain",
        country_code="ES",
        epg_id="ElPaisTV.es"
    ),
    ChannelData(
        name="Negocios",
        url="https://streaming013.gestec-video.com/hls/negociostv.m3u8",
        logo="https://pbs.twimg.com/profile_images/1321367703731523584/bNMmbetI_200x200.jpg",
        group="Spain",
        country_code="ES",
        epg_id="NegociosTV.es"
    ),
    ChannelData(
        name="Squirrel",
        url="https://tsw.streamingwebtv24.it:1936/inteccdn1/inteccdn1/playlist.m3u8",
        logo="https://i.imgur.com/urF0kYA.png",
        group="Spain",
        country_code="ES",
        epg_id="Squirrel.es"
    ),
    ChannelData(
        name="BOM Cine",
        url="https://tsw.streamingwebtv24.it:1936/inteccdn3/inteccdn3/playlist.m3u8",
        logo="https://i.imgur.com/cqhofMU.png",
        group="Spain",
        country_code="ES",
        epg_id="BomCine.es"
    ),
    ChannelData(
        name="Telemadrid",
        url="https://telemadrid-23-secure2.akamaized.net/master.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/TeleMadrid.svg/512px-TeleMadrid.svg.png",
        group="Spain",
        country_code="ES",
        epg_id="Telemadrid.es"
    ),
    ChannelData(
        name="La Otra",
        url="https://laotra-1-23-secure2.akamaized.net/master.m3u8",
        logo="https://i.imgur.com/W1UZyXH.png",
        group="Spain",
        country_code="ES",
        epg_id="LaOtra.es"
    ),
    ChannelData(
        name="Canal Sur Andalucía",
        url="https://d35x6iaiw8f75z.cloudfront.net/v1/master/3722c60a815c199d9c0ef36c5b73da68a62b09d1/cc-kbwsl0jk1bvoo/canal_sur_andalucia_es.m3u8",
        logo="https://i.imgur.com/WcVOXPr.png",
        group="Spain",
        country_code="ES",
        epg_id="CanalSurAndalucia.es"
    ),
    ChannelData(
        name="La 8 Mediterráneo",
        url="https://streaming004.gestec-video.com/hls/8TV.m3u8",
        logo="https://graph.facebook.com/la8mediterraneo/picture?width=200&height=200",
        group="Spain",
        country_code="ES",
        epg_id="La8Mediterraneo.es"
    ),
    ChannelData(
        name="Televisión Canaria Ⓨ",
        url="https://www.youtube.com/user/TelevisionCanaria/live",
        logo="https://i.imgur.com/68LNS8e.png",
        group="Spain",
        country_code="ES",
        epg_id="TVCanaria.es"
    ),
    ChannelData(
        name="IB3 Global Ⓨ",
        url="https://www.youtube.com/c/ib3/live",
        logo="https://raw.githubusercontent.com/tv-logo/tv-logos/refs/heads/main/countries/spain/ib3-es.png",
        group="Spain",
        country_code="ES",
        epg_id="IB3.es"
    ),
    ChannelData(
        name="Canal Extremadura",
        url="https://cdnapisec.kaltura.com/p/5581662/sp/558166200/playManifest/entryId/1_1u7ssdy3/protocol/https/format/applehttp/flavorIds/1_8xbndriw/a.m3u8",
        logo="https://i.imgur.com/xBeywIA.png",
        group="Spain",
        country_code="ES",
        epg_id="CanalExtremadura.es"
    ),
    ChannelData(
        name="Aragón TV Ⓢ",
        url="https://cartv.streaming.aranova.es/hls/live/aragontv_canal1.m3u8",
        logo="https://i.imgur.com/8H3Q07b.png",
        group="Spain",
        country_code="ES",
        epg_id="AragonTV.es"
    ),
    ChannelData(
        name="ETB1",
        url="https://multimedia.eitb.eus/live-content/etb1hd-hls/master.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/commons/thumb/f/f4/ETB1_2022_logo.svg/512px-ETB1_2022_logo.svg.png",
        group="Spain",
        country_code="ES",
        epg_id="ETB1.es"
    ),
    ChannelData(
        name="ETB2",
        url="https://multimedia.eitb.eus/live-content/etb2hd-hls/master.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/commons/thumb/c/c4/ETB2_2022_logo.svg/512px-ETB2_2022_logo.svg.png",
        group="Spain",
        country_code="ES",
        epg_id="ETB2.es"
    ),
    ChannelData(
        name="TV3",
        url="http://185.189.225.150:85/tv3/index.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/commons/thumb/c/cb/TV3.svg/300px-TV3.svg.png",
        group="Spain",
        country_code="ES",
        epg_id="TV3.es"
    ),
    ChannelData(
        name="TV3Cat Ⓖ",
        url="https://directes3-tv-int.3catdirectes.cat/live-content/tvi-hls/master.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/commons/thumb/9/97/TV3CAT.svg/512px-TV3CAT.svg.png",
        group="Spain",
        country_code="ES",
        epg_id="TV3CAT.es"
    ),
    ChannelData(
        name="3/24",
        url="https://directes-tv-int.3catdirectes.cat/live-origin/canal324-hls/master.m3u8",
        logo="https://raw.githubusercontent.com/tv-logo/tv-logos/refs/heads/main/countries/spain/3-24-es.png",
        group="Spain",
        country_code="ES",
        epg_id="324.es"
    ),
    ChannelData(
        name="Bon Dia",
        url="https://directes-tv-int.3catdirectes.cat/live-content/bondia-hls/master.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/commons/4/4f/Logo_Bon_Dia_TV.png",
        group="Spain",
        country_code="ES",
        epg_id="BonDiaTV.es"
    ),
    ChannelData(
        name="SX3 Ⓖ",
        url="https://directes-tv-cat.3catdirectes.cat/live-content/super3-hls/master.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/commons/thumb/0/01/SX3_logo.svg/2880px-SX3_logo.svg.png",
        group="Spain",
        country_code="ES",
        epg_id="SX3.es"
    ),
    ChannelData(
        name="El 33 Ⓖ",
        url="https://directes-tv-cat.3catdirectes.cat/live-origin/c33-super3-hls/master.m3u8",
        logo="https://raw.githubusercontent.com/tv-logo/tv-logos/refs/heads/main/countries/spain/el-33-es.png",
        group="Spain",
        country_code="ES",
        epg_id="El33.es"
    ),
    ChannelData(
        name="Esport3 Ⓖ",
        url="https://directes-tv-es.3catdirectes.cat/live-origin/esport3-hls/master.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Esport3.svg/1200px-Esport3.svg.png",
        group="Spain",
        country_code="ES",
        epg_id="Esport3.es"
    ),
    ChannelData(
        name="Canal TE24",
        url="https://ingest1-video.streaming-pro.com/esportsteABR/etestream/playlist.m3u8",
        logo="https://i.ibb.co/3ynghbW/logox2.png",
        group="Spain",
        country_code="ES",
        epg_id="CanalTerresdelEbre.es"
    ),
    ChannelData(
        name="À Punt TV",
        url="https://bcovlive-a.akamaihd.net/8499d938ef904e39b58a4adec2ddeada/eu-west-1/6057955885001/playlist_dvr.m3u8",
        logo="https://i.imgur.com/M88LoNl.png",
        group="Spain",
        country_code="ES",
        epg_id="APunt.es"
    ),
    ChannelData(
        name="7 Región de Murcia Ⓢ",
        url="https://rtv-murcia-live.globalmest.com/principal/smil:principal.smil/playlist.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/commons/thumb/2/26/La_7_logo.svg/150px-La_7_logo.svg.png",
        group="Spain",
        country_code="ES",
        epg_id="La7.es"
    ),
    ChannelData(
        name="Canal 4 Tenerife",
        url="https://videoserver.tmcreativos.com:19360/ccxwhsfcnq/ccxwhsfcnq.m3u8",
        logo="https://i.imgur.com/Egymir4.png",
        group="Spain",
        country_code="ES",
        epg_id="Canal4Tenerife.es"
    ),
    ChannelData(
        name="Televisión Melilla",
        url="https://tvmelilla-hls-rm-lw.flumotion.com/playlist.m3u8",
        logo="https://raw.githubusercontent.com/tv-logo/tv-logos/refs/heads/main/countries/spain/television-melilla-es.png",
        group="Spain",
        country_code="ES",
        epg_id="TelevisionMelilla.es"
    ),
    ChannelData(
        name="La 1 (Catalunya)",
        url="https://rtvelivestream-clnx.rtve.es/rtvesec/cat/la1_cat_main_dvr.m3u8",
        logo="https://i.imgur.com/NbesiPn.png",
        group="Spain",
        country_code="ES",
        epg_id="La1Catalunya.es"
    ),
    ChannelData(
        name="La 1 (Canarias)",
        url="https://rtvelivestream-clnx.rtve.es/rtvesec/can/la1_can_main_720.m3u8",
        logo="https://i.imgur.com/NbesiPn.png",
        group="Spain",
        country_code="ES",
        epg_id="La1Canarias.es"
    ),
    ChannelData(
        name="La 2 (Catalunya)",
        url="https://rtvelivestream.akamaized.net/rtvesec/cat/la2_cat_main_dvr.m3u8",
        logo="https://i.imgur.com/DmuTwDw.png",
        group="Spain",
        country_code="ES",
        epg_id="La2Catalunya.es"
    ),
    ChannelData(
        name="La 2 (Canarias)",
        url="https://ztnr.rtve.es/ztnr/5468585.m3u8",
        logo="https://i.imgur.com/DmuTwDw.png",
        group="Spain",
        country_code="ES",
        epg_id="La2Canarias.es"
    ),
]
