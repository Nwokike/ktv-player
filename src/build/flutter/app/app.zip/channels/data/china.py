from channels.base import ChannelData

group_name = "China"
country_code = "CN"

channels = [
    ChannelData(
        name="CCTV-1 综合",
        url="https://node1.olelive.com:6443/live/CCTV1HD/hls.m3u8",
        logo="https://i.imgur.com/uHU6Vc0.png",
        group="China",
        country_code="CN",
        epg_id="CCTV1.cn"
    ),
    ChannelData(
        name="CCTV-2 财经",
        url="https://node1.olelive.com:6443/live/CCTV2HD/hls.m3u8",
        logo="https://i.imgur.com/6C9JEYt.png",
        group="China",
        country_code="CN",
        epg_id="CCTV2.cn"
    ),
    ChannelData(
        name="CCTV-4 中文国际（亚） Ⓨ",
        url="https://www.youtube.com/channel/UC4K_LI-Tn3-LshNgG0-YypQ/live",
        logo="https://i.imgur.com/ovUSVEQ.png",
        group="China",
        country_code="CN",
        epg_id="CCTV4Asia.cn"
    ),
    ChannelData(
        name="CCTV-4 中文国际（美） Ⓢ",
        url="https://global.cgtn.cicc.media.caton.cloud/master/cgtn-america.m3u8",
        logo="https://i.imgur.com/1TPiRqR.png",
        group="China",
        country_code="CN",
        epg_id="CCTV4America.cn"
    ),
    ChannelData(
        name="CCTV-5 体育",
        url="https://node1.olelive.com:6443/live/CCTV5HD/hls.m3u8",
        logo="https://i.imgur.com/Mut2omN.png",
        group="China",
        country_code="CN",
        epg_id="CCTV5.cn"
    ),
    ChannelData(
        name="CCTV-5+ 体育赛事",
        url="https://node1.olelive.com:6443/live/CCTV5PHD/hls.m3u8",
        logo="https://i.imgur.com/UNjmQVS.png",
        group="China",
        country_code="CN",
        epg_id="CCTV5Plus.cn"
    ),
    ChannelData(
        name="CCTV-7 国防军事",
        url="https://node1.olelive.com:6443/live/CCTV7HD/hls.m3u8",
        logo="https://i.imgur.com/GhXlUpM.png",
        group="China",
        country_code="CN",
        epg_id="CCTV7.cn"
    ),
    ChannelData(
        name="CCTV-8 电视剧",
        url="https://node1.olelive.com:6443/live/CCTV8HD/hls.m3u8",
        logo="https://i.imgur.com/Qg1opg9.png",
        group="China",
        country_code="CN",
        epg_id="CCTV8.cn"
    ),
    ChannelData(
        name="CCTV-9 纪录",
        url="https://node1.olelive.com:6443/live/CCTV9HD/hls.m3u8",
        logo="https://i.imgur.com/Ruyzhu5.png",
        group="China",
        country_code="CN",
        epg_id="CCTV9.cn"
    ),
    ChannelData(
        name="CCTV-10 科教",
        url="https://node1.olelive.com:6443/live/CCTV10HD/hls.m3u8",
        logo="https://i.imgur.com/W8JNs1s.png",
        group="China",
        country_code="CN",
        epg_id="CCTV10.cn"
    ),
    ChannelData(
        name="CCTV-13 新闻",
        url="https://node1.olelive.com:6443/live/CCTV13HD/hls.m3u8",
        logo="https://i.imgur.com/pPO8uJN.png",
        group="China",
        country_code="CN",
        epg_id="CCTV13.cn"
    ),
    ChannelData(
        name="CCTV-17 农业农村",
        url="https://node1.olelive.com:6443/live/CCTV17HD/hls.m3u8",
        logo="https://i.imgur.com/XMsoHut.png",
        group="China",
        country_code="CN",
        epg_id="CCTV17.cn"
    ),
    ChannelData(
        name="CETV-1",
        url="http://txycsbl.centv.cn/zb/0628cetv1.m3u8",
        logo="https://i.imgur.com/AMcIAOV.png",
        group="China",
        country_code="CN",
        epg_id="CETV1.cn"
    ),
    ChannelData(
        name="CETV-2",
        url="http://txycsbl.centv.cn/zb/0822cetv2.m3u8",
        logo="https://i.imgur.com/a9mvoeP.png",
        group="China",
        country_code="CN",
        epg_id="CETV2.cn"
    ),
    ChannelData(
        name="CETV-3",
        url="http://txycsbl.centv.cn/zb/0822cetv3.m3u8",
        logo="https://i.imgur.com/t8o5ZKt.png",
        group="China",
        country_code="CN",
        epg_id="CETV3.cn"
    ),
    ChannelData(
        name="CETV-4",
        url="http://txycsbl.centv.cn/zb/0822cetv4.m3u8",
        logo="https://i.imgur.com/BRe0ybV.png",
        group="China",
        country_code="CN",
        epg_id="CETV4.cn"
    ),
    ChannelData(
        name="TV BRICS Chinese",
        url="https://brics.bonus-tv.ru/cdn/brics/chinese/playlist.m3u8",
        logo="https://i.imgur.com/896132Z.png",
        group="China",
        country_code="CN",
        epg_id="TVBRICSChinese.cn"
    ),
]
