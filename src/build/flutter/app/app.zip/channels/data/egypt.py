from channels.base import ChannelData

group_name = "Egypt"
country_code = "EG"

channels = [
    ChannelData(
        name="Aghapy TV",
        url="https://5b622f07944df.streamlock.net/aghapy.tv/aghapy.smil/playlist.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/en/e/eb/AghapyTV.jpg",
        group="Egypt",
        country_code="EG",
        epg_id="AghapyTV.eg"
    ),
    ChannelData(
        name="Al Ghad Plus",
        url="https://playlist.fasttvcdn.com/pl/ykvm3f2fhokwxqsurp9xcg/alghad-plus/playlist.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/commons/0/06/AlGhad_TV.png",
        group="Egypt",
        country_code="EG",
        epg_id="AlGhadPlus.eg"
    ),
    ChannelData(
        name="Al Ghad TV",
        url="https://eazyvwqssi.erbvr.com/alghadtv/alghadtv.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/commons/0/06/AlGhad_TV.png",
        group="Egypt",
        country_code="EG",
        epg_id="AlGhadTV.eg"
    ),
    ChannelData(
        name="Al Qahera News",
        url="https://bcovlive-a.akamaihd.net/d30cbb3350af4cb7a6e05b9eb1bfd850/eu-west-1/6057955906001/playlist.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/ar/b/b0/%D9%82%D9%86%D8%A7%D8%A9_%D8%A7%D9%84%D9%82%D8%A7%D9%87%D8%B1%D8%A9_%D8%A7%D9%84%D8%A5%D8%AE%D8%A8%D8%A7%D8%B1%D9%8A%D8%A9.png",
        group="Egypt",
        country_code="EG",
        epg_id="AlQaheraNews.eg"
    ),
    ChannelData(
        name="Alhayat TV",
        url="https://cdn3.wowza.com/5/OE5HREpIcEkySlNT/alhayat-live/ngrp:livestream_all/playlist.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/commons/8/8c/Al-Hayat_Media_Center_Logo_%28variant_2%29.svg",
        group="Egypt",
        country_code="EG",
        epg_id="AlhayatTV.eg"
    ),
    ChannelData(
        name="Coptic TV",
        url="https://5aafcc5de91f1.streamlock.net/ctvchannel.tv/ctv.smil/playlist.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/en/4/4c/Coptic_news.jpg",
        group="Egypt",
        country_code="EG",
        epg_id="CopticTV.eg"
    ),
    ChannelData(
        name="Huda TV",
        url="https://cdn.bestream.io:19360/elfaro1/elfaro1.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/commons/5/58/Logo_huda_%D8%AD%D8%AC%D9%85_%D9%83%D8%A8%D9%8A%D8%B1.gif",
        group="Egypt",
        country_code="EG",
        epg_id="HudaTV.eg"
    ),
    ChannelData(
        name="Koogi TV",
        url="https://5d658d7e9f562.streamlock.net/koogi.tv/koogi.smil/playlist.m3u8",
        logo="",
        group="Egypt",
        country_code="EG",
        epg_id="KoogiTV.eg"
    ),
    ChannelData(
        name="MBC Masr 1",
        url="https://mbc1-enc.edgenextcdn.net/out/v1/d5036cabf11e45bf9d0db410ca135c18/index.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/commons/7/7c/MBC_Masr_Logo.png",
        group="Egypt",
        country_code="EG",
        epg_id="MBCMasr1.eg"
    ),
    ChannelData(
        name="MBC Masr 2",
        url="https://shls-masr2-ak.akamaized.net/out/v1/f683685242b549f48ea8a5171e3e993a/index.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/commons/5/53/MBC_Masr_2_Logo.svg",
        group="Egypt",
        country_code="EG",
        epg_id="MBCMasr2.eg"
    ),
    ChannelData(
        name="Rotana Cinema",
        url="https://rotana.hibridcdn.net/rotana/cinemamasr_net-7Y83PP5adWixDF93/playlist.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/commons/9/92/Rotana_Cinema_Egy.png",
        group="Egypt",
        country_code="EG",
        epg_id="RotanaCinema.eg"
    ),
    ChannelData(
        name="Watan TV",
        url="https://rp.tactivemedia.com/watantv_source/live/playlist.m3u8",
        logo="",
        group="Egypt",
        country_code="EG",
        epg_id="WatanTV.eg"
    ),
]
