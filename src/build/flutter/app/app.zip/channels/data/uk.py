from channels.base import ChannelData

group_name = "UK"
country_code = "GB"

channels = [
    ChannelData(
        name="BBC One Ⓖ",
        url="https://vs-hls-pushb-uk-live.akamaized.net/x=4/i=urn:bbc:pips:service:bbc_one_yorks/iptv_hd_abr_v1.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/commons/thumb/8/8b/BBC_One_logo_2021.svg/640px-BBC_One_logo_2021.svg.png",
        group="UK",
        country_code="GB",
        epg_id="BBCOne.uk"
    ),
    ChannelData(
        name="BBC Two Ⓖ",
        url="https://vs-hls-push-uk-live.akamaized.net/x=4/i=urn:bbc:pips:service:bbc_two_hd/iptv_hd_abr_v1.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/commons/thumb/1/15/BBC_Two_logo_2021.svg/640px-BBC_Two_logo_2021.svg.png",
        group="UK",
        country_code="GB",
        epg_id="BBCTwo.uk"
    ),
    ChannelData(
        name="Channel 4 Ⓢ",
        url="http://176.65.146.105:8011/play/a07w/index.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/en/thumb/9/9b/Channel_4_%28On_Demand%29_2023.svg/569px-Channel_4_%28On_Demand%29_2023.svg.png",
        group="UK",
        country_code="GB",
        epg_id="Channel4.uk"
    ),
    ChannelData(
        name="S4C Ⓖ",
        url="https://live-uk.s4c-cdn.co.uk/out/v1/a0134f1fd5a2461b9422b574566d4442/live_uk.m3u8",
        logo="https://i.imgur.com/vrcbnBv.png",
        group="UK",
        country_code="GB",
        epg_id="S4C.uk"
    ),
    ChannelData(
        name="BBC Alba Ⓖ",
        url="https://vs-hls-pushb-uk-live.akamaized.net/x=4/i=urn:bbc:pips:service:bbc_alba/iptv_hd_abr_v1.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e3/BBC_Alba_2021.svg/640px-BBC_Alba_2021.svg.png",
        group="UK",
        country_code="GB",
        epg_id="BBCAlba.uk"
    ),
    ChannelData(
        name="BBC Four Ⓖ",
        url="https://vs-hls-pushb-uk-live.akamaized.net/x=4/i=urn:bbc:pips:service:bbc_four_hd/iptv_hd_abr_v1.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/commons/thumb/6/6d/BBC_Four_logo_2021.svg/640px-BBC_Four_logo_2021.svg.png",
        group="UK",
        country_code="GB",
        epg_id="BBCFour.uk"
    ),
    ChannelData(
        name="BBC Scotland Ⓢ Ⓖ",
        url="https://vs-hls-pushb-uk-live.akamaized.net/x=4/i=urn:bbc:pips:service:bbc_scotland_hd/pc_hd_abr_v2.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/commons/thumb/6/66/BBC_Scotland_2021_%28channel%29.svg/640px-BBC_Scotland_2021_%28channel%29.svg.png",
        group="UK",
        country_code="GB",
        epg_id="BBCScotland.uk"
    ),
    ChannelData(
        name="E4 Ⓢ",
        url="http://176.65.146.105:8011/play/E4HD/index.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/en/thumb/0/06/E4_logo_2018.svg/552px-E4_logo_2018.svg.png",
        group="UK",
        country_code="GB",
        epg_id="E4.uk"
    ),
    ChannelData(
        name="Film4 Ⓢ",
        url="http://176.65.146.105:8011/play/FILM4SD/index.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/en/thumb/5/53/Film4_logo_2018.svg/805px-Film4_logo_2018.svg.png",
        group="UK",
        country_code="GB",
        epg_id="Film4.uk"
    ),
    ChannelData(
        name="QVC UK Ⓢ",
        url="https://qvcuk-live.akamaized.net/hls/live/2097112/qvc/3/3.m3u8",
        logo="https://i.imgur.com/6TWUVrh.png",
        group="UK",
        country_code="GB",
        epg_id="QVCUK.uk"
    ),
    ChannelData(
        name="TJC",
        url="https://cdn-shop-lc-01.akamaized.net/Content/HLS_HLS/Live/channel(TJCOTT",
        logo="https://i.imgur.com/fk5rEje.png",
        group="UK",
        country_code="GB",
        epg_id="TJC.uk"
    ),
    ChannelData(
        name="BBC Three Ⓖ",
        url="https://vs-hls-pushb-uk-live.akamaized.net/x=4/i=urn:bbc:pips:service:bbc_three_hd/iptv_hd_abr_v1.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/commons/thumb/7/76/BBC_Three_2022.svg/640px-BBC_Three_2022.svg.png",
        group="UK",
        country_code="GB",
        epg_id="BBCThree.uk"
    ),
    ChannelData(
        name="GemsTV Ⓢ",
        url="http://57d6b85685bb8.streamlock.net:1935/abrgemporiaukgfx/livestream_360p/index.m3u8",
        logo="https://i.imgur.com/IR2sTag.png",
        group="UK",
        country_code="GB",
        epg_id="GemsTV.uk"
    ),
    ChannelData(
        name="4seven Ⓢ",
        url="http://176.65.146.170:8013/play/a06p/index.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/en/thumb/5/5e/4seven_logo_2018.svg/568px-4seven_logo_2018.svg.png",
        group="UK",
        country_code="GB",
        epg_id="4seven.uk"
    ),
    ChannelData(
        name="Ideal World",
        url="https://ythls.armelin.one/channel/UCJbgGTpBWuC87VFIKTTO4RQ.m3u8",
        logo="https://i.imgur.com/su6GH7i.png",
        group="UK",
        country_code="GB",
        epg_id="IdealWorldTV.uk"
    ),
    ChannelData(
        name="Blaze Ⓖ",
        url="https://live.blaze.tv/live7/blaze/bitrate1.isml/live.m3u8",
        logo="https://i.imgur.com/6UcPWP9.png",
        group="UK",
        country_code="GB",
        epg_id="Blaze.uk"
    ),
    ChannelData(
        name="Jewellery Maker",
        url="https://lo2-1.gemporia.com/abrjewellerymaker/smil:livestream.smil/playlist.m3u8",
        logo="https://i.imgur.com/O7SdkBh.png",
        group="UK",
        country_code="GB",
        epg_id="JewelleryMaker.uk"
    ),
    ChannelData(
        name="Hobby Maker",
        url="https://lo2-1.gemporia.com/abrhobbymakerukgfx/smil:livestreamFullHD.smil/playlist.m3u8",
        logo="https://i.imgur.com/VWHp5Tl.png",
        group="UK",
        country_code="GB",
        epg_id="HobbyMaker.uk"
    ),
    ChannelData(
        name="EarthXTV",
        url="https://ov.ottera.tv/live/master.m3u8?channel=earth_et",
        logo="https://i.imgur.com/AvJRFKf.png",
        group="UK",
        country_code="GB",
        epg_id="EarthXUK.uk"
    ),
    ChannelData(
        name="PBS America",
        url="https://pbs-samsunguk.amagi.tv/playlist.m3u8",
        logo="https://i.imgur.com/J4zE5z9.jpg",
        group="UK",
        country_code="GB",
        epg_id="PBSAmerica.uk"
    ),
    ChannelData(
        name="Create & Craft",
        url="https://live-hochanda.simplestreamcdn.com/live2/hochanda/bitrate1.isml/live.m3u8",
        logo="https://i.imgur.com/n65sk4L.png",
        group="UK",
        country_code="GB",
        epg_id="CreateandCraft.uk"
    ),
    ChannelData(
        name="CBBC Ⓖ",
        url="https://vs-hls-pushb-uk-live.akamaized.net/x=4/i=urn:bbc:pips:service:cbbc_hd/t=3840/v=pv14/b=5070016/main.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/commons/thumb/3/35/CBBC_%282023%29.svg/640px-CBBC_%282023%29.svg.png",
        group="UK",
        country_code="GB",
        epg_id="CBBC.uk"
    ),
    ChannelData(
        name="CBeebies Ⓖ",
        url="https://vs-hls-pushb-uk-live.akamaized.net/x=4/i=urn:bbc:pips:service:cbeebies_hd/t=3840/v=pv14/b=5070016/main.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/commons/thumb/b/b5/CBeebies_2023.svg/640px-CBeebies_2023.svg.png",
        group="UK",
        country_code="GB",
        epg_id="CBeebies.uk"
    ),
    ChannelData(
        name="BBC Parliament Ⓢ Ⓖ",
        url="https://vs-hls-pushb-uk-live.akamaized.net/x=4/i=urn:bbc:pips:service:bbc_parliament/pc_hd_abr_v2.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/commons/thumb/9/99/BBC_Parliament_2022.svg/640px-BBC_Parliament_2022.svg.png",
        group="UK",
        country_code="GB",
        epg_id="BBCParliament.uk"
    ),
    ChannelData(
        name="Sky News",
        url="https://linear021-gb-hls1-prd-ak.cdn.skycdp.com/Content/HLS_001_hd/Live/channel(skynews",
        logo="https://upload.wikimedia.org/wikipedia/en/thumb/5/57/Sky_News_logo.svg/1024px-Sky_News_logo.svg.png",
        group="UK",
        country_code="GB",
        epg_id="SkyNews.uk"
    ),
    ChannelData(
        name="GB News",
        url="https://live-gbnews.simplestreamcdn.com/live5/gbnews/bitrate1.isml/manifest.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/en/thumb/3/35/GB_News_Logo.svg/640px-GB_News_Logo.svg.png",
        group="UK",
        country_code="GB",
        epg_id="GBNews.uk"
    ),
    ChannelData(
        name="TalkTV",
        url="https://live-talktv-ssai.simplestreamcdn.com/v1/master/82267e84b9e5053b3fd0ade12cb1a146df74169a/talktv-live/index.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/en/8/83/TalkTV_logo.png",
        group="UK",
        country_code="GB",
        epg_id="TalkTV.uk"
    ),
    ChannelData(
        name="Arise News",
        url="https://liveedge-arisenews.visioncdn.com/live-hls/arisenews/arisenews/arisenews_web/master.m3u8",
        logo="https://i.imgur.com/B5IXKIb.png",
        group="UK",
        country_code="GB",
        epg_id="AriseNews.uk"
    ),
    ChannelData(
        name="France 24",
        url="https://ythls.armelin.one/channel/UCQfwfsi5VrQ8yKZ-UWmAEFg.m3u8",
        logo="https://i.imgur.com/61MSiq9.png",
        group="UK",
        country_code="GB",
        epg_id="France24English.fr"
    ),
    ChannelData(
        name="Bloomberg TV",
        url="https://bloomberg.com/media-manifest/streams/eu.m3u8",
        logo="https://d2n0069hmnqmmx.cloudfront.net/epgdata/1.0/newchanlogos/512/512/skychb1074.png",
        group="UK",
        country_code="GB",
        epg_id="BloombergTVEurope.uk"
    ),
    ChannelData(
        name="NHK World Japan",
        url="https://nhkwlive-ojp.akamaized.net/hls/live/2003459/nhkwlive-ojp-en/index_4M.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/commons/thumb/8/8d/NHK_World-Japan_TV.svg/512px-NHK_World-Japan_TV.svg.png",
        group="UK",
        country_code="GB",
        epg_id="NHKWorldJapan.jp"
    ),
    ChannelData(
        name="Arirang World",
        url="http://amdlive.ctnd.com.edgesuite.net/arirang_1ch/smil:arirang_1ch.smil/chunklist_b2256000_sleng.m3u8",
        logo="https://raw.githubusercontent.com/tv-logo/tv-logos/67cfa9368d2d135744732a3aed3baecb3fadcf13/countries/international/arirang-int.png",
        group="UK",
        country_code="GB",
        epg_id="ArirangWorld.kr"
    ),
    ChannelData(
        name="TRT World",
        url="https://api.trtworld.com/livestream/v1/WcM3Oa2LHD9iUjWDSRUI335NkMWVTUV351H56dqC/master.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/commons/thumb/2/27/TRT_World.svg/512px-TRT_World.svg.png",
        group="UK",
        country_code="GB",
        epg_id="TRTWorld.tr"
    ),
    ChannelData(
        name="SportyStuff TV",
        url="https://cdn.rtmp1.vodhosting.com/hls/SportyStuffTV.m3u8",
        logo="https://i.imgur.com/uIgxHSY.png",
        group="UK",
        country_code="GB",
        epg_id="SportyStuffTV.uk"
    ),
    ChannelData(
        name="4Music Ⓖ",
        url="https://csm-e-boxplus.tls1.yospace.com/csm/extlive/boxplus01,boxhits-alldev.m3u8?spotxc1=195996&spotxc2=190878&yo.up=https://boxtv.secure.footprint.net/boxhits/",
        logo="https://upload.wikimedia.org/wikipedia/en/thumb/4/49/4Music_logo_2018.svg/512px-4Music_logo_2018.svg.png",
        group="UK",
        country_code="GB",
        epg_id="4Music.uk"
    ),
    ChannelData(
        name="The Box Ⓖ",
        url="https://csm-e-boxplus.tls1.yospace.com/csm/extlive/boxplus01,thebox-alldev.m3u8?yo.up=https://boxtv.secure.footprint.net/thebox/",
        logo="https://i.imgur.com/e1Cf4Li.png",
        group="UK",
        country_code="GB",
        epg_id="TheBoxUK.uk"
    ),
    ChannelData(
        name="KISS Ⓖ",
        url="https://csm-e-boxplus.tls1.yospace.com/csm/extlive/boxplus01,kiss-alldev.m3u8?spotxc1=195996&spotxc2=190878&yo.up=https://boxtv.secure.footprint.net/kiss/",
        logo="https://i.imgur.com/47ZkVhO.png",
        group="UK",
        country_code="GB",
        epg_id="KissTVUK.uk"
    ),
    ChannelData(
        name="Magic Ⓖ",
        url="https://csm-e-boxplus.tls1.yospace.com/csm/extlive/boxplus01,magic-alldev.m3u8?yo.up=https%3A%2F%2Fboxtv.secure.footprint.net%2Fmagic%2F&spotxc1=195996&spotxc2=190878",
        logo="https://i.imgur.com/e1Cf4Li.png",
        group="UK",
        country_code="GB",
        epg_id="Magic.uk"
    ),
    ChannelData(
        name="Kerrang!",
        url="https://csm-e-boxplus.tls1.yospace.com/csm/extlive/boxplus01,kerrang-alldev.m3u8?yo.up=http://boxtv-origin-elb.cds1.yospace.com/uploads/kerrang/",
        logo="https://i.imgur.com/3mwf8Uq.png",
        group="UK",
        country_code="GB",
        epg_id="Kerrang.uk"
    ),
    ChannelData(
        name="QVC Beauty Ⓢ",
        url="https://qvcuk-live.akamaized.net/hls/live/2097112/qby/3/3.m3u8",
        logo="https://i.imgur.com/ZBHtqk1.png",
        group="UK",
        country_code="GB",
        epg_id="QVCBeautyUK.uk"
    ),
    ChannelData(
        name="QVC Extra Ⓢ",
        url="https://qvcuk-live.akamaized.net/hls/live/2097112/qex/3/3.m3u8",
        logo="https://i.imgur.com/TIe5T9Z.png",
        group="UK",
        country_code="GB",
        epg_id="QVCExtraUK.uk"
    ),
    ChannelData(
        name="QVC Style Ⓢ",
        url="https://qvcuk-live.akamaized.net/hls/live/2097112/qst/3/3.m3u8",
        logo="https://i.imgur.com/6HZlLL3.png",
        group="UK",
        country_code="GB",
        epg_id="QVCStyleUK.uk"
    ),
    ChannelData(
        name="Now 70s",
        url="https://lightning-now70s-samsungnz.amagi.tv/playlist.m3u8",
        logo="https://i.imgur.com/qiCCX5X.png",
        group="UK",
        country_code="GB",
        epg_id="Now70s.uk"
    ),
    ChannelData(
        name="Now 80s",
        url="https://lightning-now80s-samsunguk.amagi.tv/playlist.m3u8",
        logo="https://i.imgur.com/8paz37m.png",
        group="UK",
        country_code="GB",
        epg_id="Now80s.uk"
    ),
    ChannelData(
        name="Now Rock",
        url="https://lightning-now90s-samsungnz.amagi.tv/playlist.m3u8",
        logo="https://upload.wikimedia.org/wikipedia/en/8/89/NOW_Rock_logo.png",
        group="UK",
        country_code="GB",
        epg_id="NowRock.uk"
    ),
    ChannelData(
        name="BBC World News Ⓢ",
        url="http://ott-cdn.ucom.am/s24/index.m3u8",
        logo="https://i.imgur.com/joD38lo.png",
        group="UK",
        country_code="GB",
        epg_id=""
    ),
    ChannelData(
        name="BBC Radio 1",
        url="http://as-hls-ww-live.akamaized.net/pool_904/live/ww/bbc_radio_one/bbc_radio_one.isml/bbc_radio_one-audio%3d96000.norewind.m3u8",
        logo="https://experiencersinternational.github.io/tvsetup/tvg-ico/bbcrd1-epg.png",
        group="UK",
        country_code="GB",
        epg_id="BBCRadio1.uk"
    ),
    ChannelData(
        name="BBC Radio 2",
        url="http://as-hls-ww-live.akamaized.net/pool_904/live/ww/bbc_radio_two/bbc_radio_two.isml/bbc_radio_two-audio%3d96000.norewind.m3u8",
        logo="https://experiencersinternational.github.io/tvsetup/tvg-ico/bbcrd2-epg.png",
        group="UK",
        country_code="GB",
        epg_id="BBCRadio2.uk"
    ),
    ChannelData(
        name="BBC Radio 3",
        url="http://as-hls-ww-live.akamaized.net/pool_904/live/ww/bbc_radio_three/bbc_radio_three.isml/bbc_radio_three-audio%3d96000.norewind.m3u8",
        logo="https://experiencersinternational.github.io/tvsetup/tvg-ico/bbcrd3-epg.png",
        group="UK",
        country_code="GB",
        epg_id="BBCRadio3.uk"
    ),
    ChannelData(
        name="BBC Radio 4",
        url="http://as-hls-ww-live.akamaized.net/pool_904/live/ww/bbc_radio_fourfm/bbc_radio_fourfm.isml/bbc_radio_fourfm-audio%3d96000.norewind.m3u8",
        logo="https://experiencersinternational.github.io/tvsetup/tvg-ico/bbcrd4-epg.png",
        group="UK",
        country_code="GB",
        epg_id="BBCRadio4FM.uk"
    ),
    ChannelData(
        name="BBC Radio 5 Live",
        url="http://as-hls-ww-live.akamaized.net/pool_904/live/ww/bbc_radio_five_live/bbc_radio_five_live.isml/bbc_radio_five_live-audio%3d96000.norewind.m3u8",
        logo="https://experiencersinternational.github.io/tvsetup/tvg-ico/bbcrd5l-epg.png",
        group="UK",
        country_code="GB",
        epg_id="BBCRadio5Live.uk"
    ),
    ChannelData(
        name="BBC Radio 6 Music",
        url="http://as-hls-ww-live.akamaized.net/pool_904/live/ww/bbc_6music/bbc_6music.isml/bbc_6music-audio%3d96000.norewind.m3u8",
        logo="https://experiencersinternational.github.io/tvsetup/tvg-ico/bbcrd6-epg.png",
        group="UK",
        country_code="GB",
        epg_id="BBCRadio6Music.uk"
    ),
    ChannelData(
        name="BBC Radio 1Xtra",
        url="http://as-hls-ww-live.akamaized.net/pool_904/live/ww/bbc_1xtra/bbc_1xtra.isml/bbc_1xtra-audio%3d96000.norewind.m3u8",
        logo="https://experiencersinternational.github.io/tvsetup/tvg-ico/bbcrd1x-epg.png",
        group="UK",
        country_code="GB",
        epg_id="BBCRadio1Xtra.uk"
    ),
    ChannelData(
        name="BBC Radio 4 Extra",
        url="http://as-hls-ww-live.akamaized.net/pool_904/live/ww/bbc_radio_four_extra/bbc_radio_four_extra.isml/bbc_radio_four_extra-audio%3d96000.norewind.m3u8",
        logo="https://experiencersinternational.github.io/tvsetup/tvg-ico/bbcrd4x-epg.png",
        group="UK",
        country_code="GB",
        epg_id="BBCRadio4Extra.uk"
    ),
    ChannelData(
        name="BBC Radio 5 Sports Extra",
        url="http://as-hls-uk-live.akamaized.net/pool_904/live/uk/bbc_radio_five_live_sports_extra/bbc_radio_five_live_sports_extra.isml/bbc_radio_five_live_sports_extra-audio%3d96000.norewind.m3u8",
        logo="https://experiencersinternational.github.io/tvsetup/tvg-ico/bbcrd5s-epg.png",
        group="UK",
        country_code="GB",
        epg_id="BBCRadio5SportsExtra.uk"
    ),
    ChannelData(
        name="BBC Asian Network",
        url="http://as-hls-ww-live.akamaized.net/pool_904/live/ww/bbc_asian_network/bbc_asian_network.isml/bbc_asian_network-audio%3d96000.norewind.m3u8",
        logo="https://experiencersinternational.github.io/tvsetup/tvg-ico/bbcasiannet-epg.png",
        group="UK",
        country_code="GB",
        epg_id="BBCRadioAsianNetwork.uk"
    ),
    ChannelData(
        name="BBC World Service",
        url="http://a.files.bbci.co.uk/media/live/manifesto/audio/simulcast/hls/nonuk/sbr_low/ak/bbc_world_service.m3u8",
        logo="https://experiencersinternational.github.io/tvsetup/tvg-ico/bbcws-epg.png",
        group="UK",
        country_code="GB",
        epg_id="BBCRadioWorldService.uk"
    ),
]
