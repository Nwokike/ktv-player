from channels.base import ChannelData

group_name = "Spain VOD"
country_code = ""

channels = [
    ChannelData(
        name="HQM Arabic",
        url="https://livelist01.yowi.tv/lista/39596c72840d27b213caf4e58c39599a6f2ed203/master.m3u8",
        logo="https://hqm.es/wp-content/uploads/arabic-hqm-logo.png",
        group="Spain VOD",
        country_code="",
        epg_id="HQMArabic.es"
    ),
    ChannelData(
        name="HQM Baladas",
        url="https://livelist01.yowi.tv/lista/5d7d2c21e0ec7a8a99fd1fdbc52cbdc0782f77fc/master.m3u8",
        logo="https://hqm.es/wp-content/uploads/baladas-hqm-logo.png",
        group="Spain VOD",
        country_code="",
        epg_id="HQMBaladas.es"
    ),
    ChannelData(
        name="HQM Blues",
        url="https://livelist01.yowi.tv/lista/81c601f370e44dc566113fd752204be5f5f53b61/master.m3u8",
        logo="https://hqm.es/wp-content/uploads/blues-hqm-logo.png",
        group="Spain VOD",
        country_code="",
        epg_id="HQMBlues.es"
    ),
    ChannelData(
        name="HQM Chill Out",
        url="https://livelist01.yowi.tv/lista/183a351ddb0e57af6d735256226e6033c32219ab/master.m3u8",
        logo="https://hqm.es/wp-content/uploads/chill-out-hqm-logo.png",
        group="Spain VOD",
        country_code="",
        epg_id="HQMChillOut.es"
    ),
    ChannelData(
        name="HQM Classic",
        url="https://livelist01.yowi.tv/lista/f04129475945936b248aa723de56519ea2ff10fc/master.m3u8",
        logo="https://hqm.es/wp-content/uploads/classic-hqm-logo.png",
        group="Spain VOD",
        country_code="",
        epg_id="HQMClassic.es"
    ),
    ChannelData(
        name="HQM Dance",
        url="https://livelist01.yowi.tv/lista/57cf2f51b07ff21988a7a6f0270a66d41086d4a4/master.m3u8",
        logo="https://hqm.es/wp-content/uploads/dance-hqm-logo.png",
        group="Spain VOD",
        country_code="",
        epg_id="HQMDance.es"
    ),
    ChannelData(
        name="HQM Folk",
        url="https://livelist01.yowi.tv/lista/9f5310c179e8e840188d183be235f755b18cf703/master.m3u8",
        logo="https://hqm.es/wp-content/uploads/folk-hqm-logo.png",
        group="Spain VOD",
        country_code="",
        epg_id="HQMFolk.es"
    ),
    ChannelData(
        name="HQM Gym",
        url="https://livelist01.yowi.tv/lista/abb87f329d0ed03072b1930e9636a53e8076c8d5/master.m3u8",
        logo="https://hqm.es/wp-content/uploads/gym-hqm-logo.png",
        group="Spain VOD",
        country_code="",
        epg_id="HQMGym.es"
    ),
    ChannelData(
        name="HQM Hip Hop",
        url="https://livelist01.yowi.tv/lista/8327abc87895df4c76db1155435fdca6a3607bbd/master.m3u8",
        logo="https://hqm.es/wp-content/uploads/hip-hop-hqm-logo.png",
        group="Spain VOD",
        country_code="",
        epg_id="HQMHipHop.es"
    ),
    ChannelData(
        name="HQM Hits",
        url="https://livelist01.yowi.tv/lista/5e2db2017a8fd03f73b40ede363d1a586db4e9a6/master.m3u8",
        logo="https://hqm.es/wp-content/uploads/hits-hqm-logo.png",
        group="Spain VOD",
        country_code="",
        epg_id="HQMHits.es"
    ),
    ChannelData(
        name="HQM Jazz",
        url="https://livelist01.yowi.tv/lista/f204aa5b3f0691e69851b54b7746ef09ede26f6a/master.m3u8",
        logo="https://hqm.es/wp-content/uploads/jazz-hqm-logo.png",
        group="Spain VOD",
        country_code="",
        epg_id="HQMJazz.es"
    ),
    ChannelData(
        name="HQM Kids",
        url="https://livelist01.yowi.tv/lista/e4bc12dafe33c3ceb3e382e3acc0ec2c012cf7fd/master.m3u8",
        logo="https://hqm.es/wp-content/uploads/kids-hqm-logo.png",
        group="Spain VOD",
        country_code="",
        epg_id="HQMKids.es"
    ),
    ChannelData(
        name="HQM Latin",
        url="https://livelist01.yowi.tv/lista/9a4da7871ec57b4b63ed49597a13d09869172be0/master.m3u8",
        logo="https://hqm.es/wp-content/uploads/latin-hqm-logo.png",
        group="Spain VOD",
        country_code="",
        epg_id="HQMLatin.es"
    ),
    ChannelData(
        name="HQM Pop",
        url="https://livelist01.yowi.tv/lista/eb2fa68a058a701fa5bd2c80f6c8a6075896f71d/master.m3u8",
        logo="https://hqm.es/wp-content/uploads/pop-hqm-logo.png",
        group="Spain VOD",
        country_code="",
        epg_id="HQMPop.es"
    ),
    ChannelData(
        name="HQM Relax",
        url="https://livelist01.yowi.tv/lista/dc1b71c6fda2e687050facaa7242062cbf5a7f2a/master.m3u8",
        logo="https://hqm.es/wp-content/uploads/relax-hqm-logo.png",
        group="Spain VOD",
        country_code="",
        epg_id="HQMRelax.es"
    ),
    ChannelData(
        name="HQM Remember",
        url="https://livelist01.yowi.tv/lista/57c98e2e295a0b69b52dc5f84edc4b1b68783ba2/master.m3u8",
        logo="https://hqm.es/wp-content/uploads/remember-hqm-logo.png",
        group="Spain VOD",
        country_code="",
        epg_id="HQMRemember.es"
    ),
    ChannelData(
        name="HQM Rock",
        url="https://livelist01.yowi.tv/lista/0d6c7ccfac89946bfd41ae34c527e8d94734065c/master.m3u8",
        logo="https://hqm.es/wp-content/uploads/rock-hqm-logo.png",
        group="Spain VOD",
        country_code="",
        epg_id="HQMRock.es"
    ),
    ChannelData(
        name="HQM Spanish",
        url="https://livelist01.yowi.tv/lista/8635ae40f8d1a32eccd63d1f58b55662c9c98f9f/master.m3u8",
        logo="https://hqm.es/wp-content/uploads/spanish-hqm-logo.png",
        group="Spain VOD",
        country_code="",
        epg_id="HQMSpanish.es"
    ),
]
