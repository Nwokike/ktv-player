from channels.base import ChannelData

group_name = "Nigeria"
country_code = "NG"

channels = [
    ChannelData(
        name="Advocate Broadcasting Network",
        url="https://viewmedia7219.bozztv.com/wmedia/viewmedia100/web_045/Stream/playlist.m3u8",
        logo="https://i.imgur.com/eZrhTam.png",
        group="Nigeria",
        country_code="NG",
        epg_id="AdvocateBroadcastingNetwork.ng"
    ),
    ChannelData(
        name="AMusic Channel",
        url="http://mn-nl.mncdn.com/amusictv/amusicsrt.stream/playlist.m3u8",
        logo="https://i.imgur.com/SFKN9Vl.jpeg",
        group="Nigeria",
        country_code="NG",
        epg_id="AMusicChannel.ng"
    ),
    ChannelData(
        name="Channels 24",
        url="https://live20.bozztv.com/dvrfl06/astv/astv-channel24africa/index.m3u8",
        logo="https://i.imgur.com/ABjlIkm.png",
        group="Nigeria",
        country_code="NG",
        epg_id="Channels24.ng"
    ),
    ChannelData(
        name="Channels TV",
        url="https://cs2.push2stream.com/CHANNELSTV-DVR/playlist.m3u8",
        logo="https://i.imgur.com/O237VLC.png",
        group="Nigeria",
        country_code="NG",
        epg_id="ChannelsTV.ng"
    ),
    ChannelData(
        name="Itage TV",
        url="https://viewmedia7219.bozztv.com/wmedia/viewmedia100/web_011/Stream/playlist.m3u8",
        logo="https://i.imgur.com/ojLIfkt.jpeg",
        group="Nigeria",
        country_code="NG",
        epg_id="ItageTV.ng"
    ),
    ChannelData(
        name="LN247",
        url="https://go5lmb6oyawb-hls-live.5centscdn.com/station/3dfd3752af3d7aec5c53992c2da3a316.sdp/playlist.m3u8",
        logo="https://i.imgur.com/zGWEeZT.jpeg",
        group="Nigeria",
        country_code="NG",
        epg_id="LN247.ng"
    ),
    ChannelData(
        name="News Central",
        url="https://wf.newscentral.ng:8443/hls/stream.m3u8",
        logo="https://i.imgur.com/1oSxhmp.png",
        group="Nigeria",
        country_code="NG",
        epg_id="NewsCentral.ng"
    ),
    ChannelData(
        name="OSBC TV",
        url="https://cloud.odysee.live/content/0edfb4b7fb52d2d5ae30e052ce6b61d376fcd662/master.m3u8",
        logo="https://i.imgur.com/TwWsjy5.jpeg",
        group="Nigeria",
        country_code="NG",
        epg_id="OSBCTV.ng"
    ),
    ChannelData(
        name="Rave TV",
        url="https://viewmedia7219.bozztv.com/wmedia/viewmedia100/web_039/Stream/playlist.m3u8",
        logo="https://i.imgur.com/fDSyf6u.png",
        group="Nigeria",
        country_code="NG",
        epg_id="RaveTV.ng"
    ),
    ChannelData(
        name="Silverbird News 24",
        url="https://viewmedia7219.bozztv.com/wmedia/viewmedia100/web_029/Stream/playlist.m3u8",
        logo="https://i.imgur.com/ssEAjq5.jpeg",
        group="Nigeria",
        country_code="NG",
        epg_id="SilverbirdNews24.ng"
    ),
    ChannelData(
        name="Soundcity TV",
        url="https://cs2.push2stream.com/SOUNDCITY/playlist.m3u8",
        logo="https://i.imgur.com/zfi4SXW.png",
        group="Nigeria",
        country_code="NG",
        epg_id="SoundcityTV.ng"
    ),
    ChannelData(
        name="Superscreen TV",
        url="https://video1.getstreamhosting.com:1936/8398/8398/playlist.m3u8",
        logo="https://i.imgur.com/DuhRy48.png",
        group="Nigeria",
        country_code="NG",
        epg_id="SuperscreenTV.ng"
    ),
    ChannelData(
        name="TVC",
        url="https://tvce.gridpapaservers.com/TVCSEPT/ngrp:myStream_all/playlist.m3u8",
        logo="https://i.imgur.com/49XR2N3.jpeg",
        group="Nigeria",
        country_code="NG",
        epg_id="TVC.ng"
    ),
    ChannelData(
        name="TVC News",
        url="http://69.64.57.208/tvcnews/playlist.m3u8",
        logo="https://i.imgur.com/6ImhXFB.jpeg",
        group="Nigeria",
        country_code="NG",
        epg_id="TVCNews.ng"
    ),
    ChannelData(
        name="Waffi TV",
        url="https://oqgdro3xd4rm-hls-live.5centscdn.com/waffiitvstreaminglivetfmediacast/e0885d428bea69e372309657f3bd895f.sdp/playlist.m3u8",
        logo="https://i.imgur.com/ejlCb5g.png",
        group="Nigeria",
        country_code="NG",
        epg_id="WaffiTV.ng"
    ),
    ChannelData(
        name="Wazobia Max TV Abuja",
        url="https://wazobia.live:8333/channel/wmaxabuja.m3u8",
        logo="https://i.imgur.com/sEnLR0B.jpeg",
        group="Nigeria",
        country_code="NG",
        epg_id="WazobiaMaxTVAbuja.ng"
    ),
    ChannelData(
        name="Wazobia Max TV Nigeria",
        url="https://wazobia.live:8333/channel/wmax.m3u8",
        logo="https://i.imgur.com/sEnLR0B.jpeg",
        group="Nigeria",
        country_code="NG",
        epg_id="WazobiaMaxTVNigeria.ng"
    ),
    ChannelData(
        name="Wazobia Max TV Port Harcourt",
        url="https://wazobia.live:8333/channel/wmaxph.m3u8",
        logo="https://i.imgur.com/sEnLR0B.jpeg",
        group="Nigeria",
        country_code="NG",
        epg_id="WazobiaMaxTVPortHarcourt.ng"
    ),
]
