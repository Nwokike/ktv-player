from channels.base import ChannelData

group_name = "Chile"
country_code = "CL"

channels = [
    ChannelData(
        name="UCV Televisión",
        url="https://unlimited1-cl-isp.dps.live/ucvtv2/ucvtv2.smil/playlist.m3u8",
        logo="https://i.imgur.com/2VL4Pts.png",
        group="Chile",
        country_code="CL",
        epg_id="UCVTV.cl"
    ),
    ChannelData(
        name="TVN Ⓖ",
        url="https://sktv-forwarders.7m.pl/get.php?x=TVN",
        logo="https://i.imgur.com/WoN1dai.png",
        group="Chile",
        country_code="CL",
        epg_id="TVN.cl"
    ),
    ChannelData(
        name="24 horas",
        url="https://mdstrm.com/live-stream-playlist/57d1a22064f5d85712b20dab.m3u8",
        logo="https://i.imgur.com/0rF6Kub.png",
        group="Chile",
        country_code="CL",
        epg_id="24Horas.cl"
    ),
    ChannelData(
        name="NTV Ⓖ",
        url="https://mdstrm.com/live-stream-playlist/5aaabe9e2c56420918184c6d.m3u8",
        logo="https://i.imgur.com/pt2Kj1A.png",
        group="Chile",
        country_code="CL",
        epg_id="NTV.cl"
    ),
    ChannelData(
        name="TV Chile Ⓖ",
        url="https://mdstrm.com/live-stream-playlist/533adcc949386ce765657d7c.m3u8",
        logo="https://i.imgur.com/yCL888l.png",
        group="Chile",
        country_code="CL",
        epg_id="TVChile.cl"
    ),
    ChannelData(
        name="Canal 13",
        url="https://sktv-forwarders.7m.pl/get.php?x=Canal13",
        logo="https://i.imgur.com/JIo1HBs.png",
        group="Chile",
        country_code="CL",
        epg_id="Canal13.cl"
    ),
    ChannelData(
        name="TV+ Ⓖ",
        url="https://mdstrm.com/live-stream-playlist/5c0e8b19e4c87f3f2d3e6a59.m3u8",
        logo="https://i.imgur.com/NtuZIEJ.png",
        group="Chile",
        country_code="CL",
        epg_id="TVPlus.cl"
    ),
    ChannelData(
        name="Chilevisión Ⓖ",
        url="https://sktv-forwarders.7m.pl/get.php?x=Chilevision",
        logo="https://i.imgur.com/2Pu8yXf.png",
        group="Chile",
        country_code="CL",
        epg_id="ChileVision.cl"
    ),
    ChannelData(
        name="UChile TV",
        url="https://unlimited1-us.dps.live/uchiletv/uchiletv.smil/playlist.m3u8",
        logo="https://i.imgur.com/mF2W8Uh.png",
        group="Chile",
        country_code="CL",
        epg_id="UChileTV.cl"
    ),
    ChannelData(
        name="T13 en vivo",
        url="https://redirector.rudo.video/hls-video/10b92cafdf3646cbc1e727f3dc76863621a327fd/t13/t13.smil/playlist.m3u8",
        logo="https://i.imgur.com/3CEijac.png",
        group="Chile",
        country_code="CL",
        epg_id="T13.cl"
    ),
    ChannelData(
        name="13 Entretención",
        url="https://origin.dpsgo.com/ssai/event/BBp0VeP6QtOOlH8nu3bWTg/master.m3u8",
        logo="https://i.imgur.com/1vTno0m.png",
        group="Chile",
        country_code="CL",
        epg_id="13E.cl"
    ),
    ChannelData(
        name="13 Cultura",
        url="https://origin.dpsgo.com/ssai/event/GI-9cp_bT8KcerLpZwkuhw/master.m3u8",
        logo="https://i.imgur.com/49QkKWv.png",
        group="Chile",
        country_code="CL",
        epg_id="13C.cl"
    ),
    ChannelData(
        name="13 Prime",
        url="https://origin.dpsgo.com/ssai/event/p4mmBxEzSmKAxY1GusOHrw/master.m3u8",
        logo="https://i.imgur.com/YwDFNxs.png",
        group="Chile",
        country_code="CL",
        epg_id="13P.cl"
    ),
    ChannelData(
        name="13 Kids",
        url="https://origin.dpsgo.com/ssai/event/LhHrVtyeQkKZ-Ye_xEU75g/master.m3u8",
        logo="https://i.imgur.com/m6y9AMe.png",
        group="Chile",
        country_code="CL",
        epg_id="13Kids.cl"
    ),
    ChannelData(
        name="13 Realities",
        url="https://origin.dpsgo.com/ssai/event/g7_JOM0ORki9SR5RKHe-Kw/master.m3u8",
        logo="https://i.imgur.com/p1Qpljw.png",
        group="Chile",
        country_code="CL",
        epg_id="13Realities.cl"
    ),
    ChannelData(
        name="13 Teleseries",
        url="https://origin.dpsgo.com/ssai/event/f4TrySe8SoiGF8Lu3EIq1g/master.m3u8",
        logo="https://i.imgur.com/aJMBnse.png",
        group="Chile",
        country_code="CL",
        epg_id="13T.cl"
    ),
    ChannelData(
        name="El Pingüino TV",
        url="https://redirector.rudo.video/hls-video/339f69c6122f6d8f4574732c235f09b7683e31a5/pinguinotv/pinguinotv.smil/playlist.m3u8",
        logo="https://i.imgur.com/ohXs2NV.png",
        group="Chile",
        country_code="CL",
        epg_id="ElPinguinoTV.cl"
    ),
    ChannelData(
        name="UCL",
        url="https://redirector.rudo.video/hls-video/c54ac2799874375c81c1672abb700870537c5223/ucl/ucl.smil/playlist.m3u8",
        logo="https://i.imgur.com/JxqVHPX.png",
        group="Chile",
        country_code="CL",
        epg_id="UCL.uy"
    ),
    ChannelData(
        name="Deportes13 Ⓖ",
        url="https://redirector.rudo.video/hls-video/ey6283je82983je9823je8jowowiekldk9838274/13d/13d.smil/playlist.m3u8",
        logo="https://i.imgur.com/GRpxoPf.png",
        group="Chile",
        country_code="CL",
        epg_id="D13.cl"
    ),
    ChannelData(
        name="TVN 3",
        url="https://mdstrm.com/live-stream-playlist/5653641561b4eba30a7e4929.m3u8",
        logo="https://i.imgur.com/84lWqRi.png",
        group="Chile",
        country_code="CL",
        epg_id="TVN3.cl"
    ),
    ChannelData(
        name="Chilevisión Noticias",
        url="https://redirector.rudo.video/hls-video/10b92cafdf3646cbc1e727f3dc76863621a327fd/chvn/chvn.smil/playlist.m3u8",
        logo="https://i.imgur.com/Qh6d0A9.png",
        group="Chile",
        country_code="CL",
        epg_id="CHVNoticias.cl"
    ),
]
