from channels.base import ChannelData

group_name = "Turkey"
country_code = "TR"

channels = [
    ChannelData(
        name="TRT 1",
        url="https://tv-trt1.medya.trt.com.tr/master.m3u8",
        logo="https://i.imgur.com/j786OLG.png",
        group="Turkey",
        country_code="TR",
        epg_id="TRT1.tr"
    ),
    ChannelData(
        name="TRT 2 Ⓖ",
        url="https://tv-trt2.medya.trt.com.tr/master.m3u8",
        logo="https://i.imgur.com/lNWrOE2.png",
        group="Turkey",
        country_code="TR",
        epg_id="TRT2.tr"
    ),
    ChannelData(
        name="TRT Haber",
        url="https://tv-trthaber.medya.trt.com.tr/master.m3u8",
        logo="https://i.imgur.com/OVfo8Ab.png",
        group="Turkey",
        country_code="TR",
        epg_id="TRTHaber.tr"
    ),
    ChannelData(
        name="TRT Spor Ⓖ",
        url="https://tv-trtspor1.medya.trt.com.tr/master.m3u8",
        logo="https://i.imgur.com/N2wGZyf.png",
        group="Turkey",
        country_code="TR",
        epg_id="TRTSpor.tr"
    ),
    ChannelData(
        name="TRT Spor 2 Ⓖ",
        url="https://tv-trtspor2.medya.trt.com.tr/master.m3u8",
        logo="https://i.imgur.com/ysKteM8.png",
        group="Turkey",
        country_code="TR",
        epg_id=""
    ),
    ChannelData(
        name="TRT Çocuk",
        url="https://tv-trtcocuk.medya.trt.com.tr/master.m3u8",
        logo="https://i.imgur.com/QLFmD6d.png",
        group="Turkey",
        country_code="TR",
        epg_id="TRTCocuk.tr"
    ),
    ChannelData(
        name="TRT Müzik",
        url="https://tv-trtmuzik.medya.trt.com.tr/master.m3u8",
        logo="https://i.imgur.com/fIVFCEd.png",
        group="Turkey",
        country_code="TR",
        epg_id=""
    ),
    ChannelData(
        name="TRT Belgesel",
        url="https://tv-trtbelgesel.medya.trt.com.tr/master.m3u8",
        logo="https://i.imgur.com/MGO87pe.png",
        group="Turkey",
        country_code="TR",
        epg_id="TRTBelgesel.tr"
    ),
    ChannelData(
        name="TRT Avaz",
        url="https://tv-trtavaz.medya.trt.com.tr/master.m3u8",
        logo="https://i.imgur.com/VhTwXu5.png",
        group="Turkey",
        country_code="TR",
        epg_id="TRTAvaz.tr"
    ),
    ChannelData(
        name="TRT Kurdî",
        url="https://tv-trtkurdi.medya.trt.com.tr/master.m3u8",
        logo="https://i.imgur.com/6BpymfB.png",
        group="Turkey",
        country_code="TR",
        epg_id="TRTKurdi.tr"
    ),
    ChannelData(
        name="TRT Arabi",
        url="https://tv-trtarabi.medya.trt.com.tr/master.m3u8",
        logo="https://i.imgur.com/yyhWOZs.png",
        group="Turkey",
        country_code="TR",
        epg_id="TRTArabi.tr"
    ),
    ChannelData(
        name="TRT World",
        url="https://tv-trtworld.medya.trt.com.tr/master.m3u8",
        logo="https://i.imgur.com/JEA2xpv.png",
        group="Turkey",
        country_code="TR",
        epg_id="TRTWorld.tr"
    ),
    ChannelData(
        name="TRT Türk",
        url="https://tv-trtturk.medya.trt.com.tr/master.m3u8",
        logo="https://i.imgur.com/OSTOQNw.png",
        group="Turkey",
        country_code="TR",
        epg_id="TRTTurk.tr"
    ),
    ChannelData(
        name="TRT EBA Ilkokul",
        url="https://tv-e-okul00.medya.trt.com.tr/master.m3u8",
        logo="https://i.imgur.com/wDvZfk8.png",
        group="Turkey",
        country_code="TR",
        epg_id=""
    ),
    ChannelData(
        name="TRT EBA Ortaokul",
        url="https://tv-e-okul01.medya.trt.com.tr/master.m3u8",
        logo="https://i.imgur.com/yfPTvRx.png",
        group="Turkey",
        country_code="TR",
        epg_id=""
    ),
    ChannelData(
        name="TRT EBA Lise",
        url="https://tv-e-okul02.medya.trt.com.tr/master.m3u8",
        logo="https://i.imgur.com/IebUZx1.png",
        group="Turkey",
        country_code="TR",
        epg_id=""
    ),
]
