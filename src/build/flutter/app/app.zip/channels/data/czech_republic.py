from channels.base import ChannelData

group_name = "Czech Republic"
country_code = "CZ"

channels = [
    ChannelData(
        name="ČT1 Ⓖ",
        url="https://sktv.plainrock127.xyz/get.php?x=CT1",
        logo="https://i.imgur.com/qBlEbN3.png",
        group="Czech Republic",
        country_code="CZ",
        epg_id="CT1.cz"
    ),
    ChannelData(
        name="ČT2 Ⓖ",
        url="https://sktv.plainrock127.xyz/get.php?x=CT2",
        logo="https://i.imgur.com/HpnGC6A.png",
        group="Czech Republic",
        country_code="CZ",
        epg_id="CT2.cz"
    ),
    ChannelData(
        name="ČT24",
        url="https://sktv.plainrock127.xyz/get.php?x=CT24",
        logo="https://i.imgur.com/pUMRFs1.png",
        group="Czech Republic",
        country_code="CZ",
        epg_id="CT24.cz"
    ),
    ChannelData(
        name="ČT sport Ⓖ",
        url="https://sktv.plainrock127.xyz/get.php?x=CTsport",
        logo="https://i.imgur.com/I2dltZW.png",
        group="Czech Republic",
        country_code="CZ",
        epg_id="CTSport.cz"
    ),
    ChannelData(
        name="ČT :D",
        url="https://sktv.plainrock127.xyz/get.php?x=CT_D",
        logo="https://i.imgur.com/Pa5rLpA.png",
        group="Czech Republic",
        country_code="CZ",
        epg_id="CTDecko.cz"
    ),
    ChannelData(
        name="ČT art",
        url="https://sktv.plainrock127.xyz/get.php?x=CTart",
        logo="https://i.imgur.com/u8mfETB.png",
        group="Czech Republic",
        country_code="CZ",
        epg_id="CTart.cz"
    ),
    ChannelData(
        name="ČT sport Plus Ⓖ",
        url="https://sktv.plainrock127.xyz/get.php?x=CTsportPlus",
        logo="https://i.imgur.com/5JiMynW.png",
        group="Czech Republic",
        country_code="CZ",
        epg_id=""
    ),
    ChannelData(
        name="JOJ Family Ⓢ",
        url="https://live.cdn.joj.sk/live/hls/family-540.m3u8",
        logo="https://i.imgur.com/IZHIAAj.png",
        group="Czech Republic",
        country_code="CZ",
        epg_id="JojFamily.sk"
    ),
    ChannelData(
        name="Šlágr Originál Ⓢ",
        url="https://stream-6.mazana.tv/slagr.m3u",
        logo="https://i.imgur.com/fQcx9S2.png",
        group="Czech Republic",
        country_code="CZ",
        epg_id="SlagrOriginal.cz"
    ),
    ChannelData(
        name="Šlágr Muzika Ⓢ",
        url="https://stream-33.mazana.tv/slagr2.m3u",
        logo="https://i.imgur.com/J9YHDVS.png",
        group="Czech Republic",
        country_code="CZ",
        epg_id="SlagrMuzika.cz"
    ),
    ChannelData(
        name="Šlágr Premium Ⓢ",
        url="https://stream-15.mazana.tv/slagrpremium.m3u",
        logo="https://i.imgur.com/Lp0IqDx.png",
        group="Czech Republic",
        country_code="CZ",
        epg_id="SlagrPremium.cz"
    ),
    ChannelData(
        name="Prima Ⓖ",
        url="https://prima-ott-live.ssl.cdn.cra.cz/channels/prima_family/playlist/cze/live_hd.m3u8?offsetSeconds=0&url=0",
        logo="https://i.imgur.com/0aHT2Nj.png",
        group="Czech Republic",
        country_code="CZ",
        epg_id="Prima.cz"
    ),
    ChannelData(
        name="CNN Prima News",
        url="https://prima-ott-live.ssl.cdn.cra.cz/channels/prima_cnn/playlist/cze/live_hd.m3u8?offsetSeconds=0&url=0",
        logo="https://i.imgur.com/Il7t0bU.png",
        group="Czech Republic",
        country_code="CZ",
        epg_id="CNNPrimaNews.cz"
    ),
    ChannelData(
        name="Prima Zoom Ⓖ",
        url="https://prima-ott-live.ssl.cdn.cra.cz/channels/prima_zoom/playlist/cze/live_hd.m3u8?offsetSeconds=0&url=0",
        logo="https://i.imgur.com/zuzBucZ.png",
        group="Czech Republic",
        country_code="CZ",
        epg_id="PrimaZoom.cz"
    ),
    ChannelData(
        name="Prima Love Ⓖ",
        url="https://prima-ott-live.ssl.cdn.cra.cz/channels/prima_love/playlist/cze/live_hd.m3u8?offsetSeconds=0&url=0",
        logo="https://i.imgur.com/TOCZc3Y.png",
        group="Czech Republic",
        country_code="CZ",
        epg_id="PrimaLove.cz"
    ),
    ChannelData(
        name="Prima STAR Ⓖ",
        url="https://prima-ott-live.ssl.cdn.cra.cz/channels/prima_star/playlist/cze/live_hd.m3u8?offsetSeconds=0&url=0",
        logo="https://i.imgur.com/tQGwvNs.png",
        group="Czech Republic",
        country_code="CZ",
        epg_id="PrimaStar.cz"
    ),
    ChannelData(
        name="Prima Krimi Ⓖ",
        url="https://prima-ott-live.ssl.cdn.cra.cz/channels/prima_krimi/playlist/cze/live_hd.m3u8?offsetSeconds=0&url=0",
        logo="https://i.imgur.com/Dn2YxrA.png",
        group="Czech Republic",
        country_code="CZ",
        epg_id="PrimaKrimi.cz"
    ),
    ChannelData(
        name="Prima MAX Ⓖ",
        url="https://prima-ott-live.ssl.cdn.cra.cz/channels/prima_max/playlist/cze/live_hd.m3u8?offsetSeconds=0&url=0",
        logo="https://i.imgur.com/QaEakvm.png",
        group="Czech Republic",
        country_code="CZ",
        epg_id="PrimaMax.cz"
    ),
    ChannelData(
        name="Prima Cool Ⓖ",
        url="https://prima-ott-live.ssl.cdn.cra.cz/channels/prima_cool/playlist/cze/live_hd.m3u8?offsetSeconds=0&url=0",
        logo="https://i.imgur.com/JMHWmcJ.png",
        group="Czech Republic",
        country_code="CZ",
        epg_id="PrimaCool.cz"
    ),
    ChannelData(
        name="Prima Show Ⓖ",
        url="https://prima-ott-live.ssl.cdn.cra.cz/channels/prima_show/playlist/cze/live_hd.m3u8?offsetSeconds=0&url=0",
        logo="https://i.imgur.com/zX4NTJ5.png",
        group="Czech Republic",
        country_code="CZ",
        epg_id="PrimaShow.cz"
    ),
    ChannelData(
        name="Óčko Ⓢ",
        url="https://ocko-live.ssl.cdn.cra.cz/channels/ocko/playlist.m3u8",
        logo="https://i.imgur.com/iPmpsnN.png",
        group="Czech Republic",
        country_code="CZ",
        epg_id="Ocko.cz"
    ),
    ChannelData(
        name="Óčko Star Ⓢ",
        url="https://ocko-live.ssl.cdn.cra.cz/channels/ocko_gold/playlist.m3u8",
        logo="https://i.imgur.com/tGzQFWw.png",
        group="Czech Republic",
        country_code="CZ",
        epg_id="OckoStar.cz"
    ),
    ChannelData(
        name="Óčko Expres Ⓢ",
        url="https://ocko-live.ssl.cdn.cra.cz/channels/ocko_expres/playlist.m3u8",
        logo="https://i.imgur.com/e731JNS.png",
        group="Czech Republic",
        country_code="CZ",
        epg_id="OckoExpres.cz"
    ),
    ChannelData(
        name="Retro Music Television Ⓢ",
        url="https://stream.mediawork.cz/retrotv/smil:retrotv2.smil/playlist.m3u8",
        logo="https://i.imgur.com/a6S2Yo4.png",
        group="Czech Republic",
        country_code="CZ",
        epg_id="RetroMusicTV.cz"
    ),
    ChannelData(
        name="TN Live",
        url="https://sktv.plainrock127.xyz/get.php?x=NovaTNLive",
        logo="https://i.imgur.com/9P7ZyFu.png",
        group="Czech Republic",
        country_code="CZ",
        epg_id=""
    ),
    ChannelData(
        name="Praha TV",
        url="https://stream.polar.cz/prahatv/prahatvlive-1/playlist.m3u8",
        logo="https://www.praga2018.cz/wp-content/uploads/logo-prahatv.png",
        group="Czech Republic",
        country_code="CZ",
        epg_id="PrahaTV.cz"
    ),
    ChannelData(
        name="TV Nova Ⓢ",
        url="https://sktv.plainrock127.xyz/get.php?x=Nova",
        logo="https://i.imgur.com/77ztmd9.png",
        group="Czech Republic",
        country_code="CZ",
        epg_id="tvnova.cz"
    ),
    ChannelData(
        name="Východoceská TV",
        url="https://stream.polar.cz/vctv/vctvlive-1/playlist.m3u8",
        logo="https://i.imgur.com/4Wwptd3.png",
        group="Czech Republic",
        country_code="CZ",
        epg_id="V1.cz"
    ),
    ChannelData(
        name="UTV (Czech Republic)",
        url="https://vysilani.zaktv.cz/broadcast/hls/utv/index.m3u8",
        logo="https://imgur.com/ulfeIwM.png",
        group="Czech Republic",
        country_code="CZ",
        epg_id="utv.cz"
    ),
]
